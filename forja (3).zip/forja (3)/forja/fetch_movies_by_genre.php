<?php
include 'connection/connect.php';

$movies = [];

// Fetch genres from the database
$genreStmt = $conn->prepare('SELECT genre_id, genre_name FROM genres');
$genreStmt->execute();
$genreResult = $genreStmt->get_result();

// Fetch movies based on genre if a specific genre is selected
if (isset($_GET['genre_id'])) {
    $selectedGenreId = intval($_GET['genre_id']);
    
    // Prepare the query to fetch movies by genre
    $movieStmt = $conn->prepare('
        SELECT m.movie_id, m.title, m.release_year, m.rating, m.duration, m.poster
        FROM movies m
        JOIN movie_genres mg ON m.movie_id = mg.movie_id
        WHERE mg.genre_id = ?');
    $movieStmt->bind_param('i', $selectedGenreId);
    $movieStmt->execute();
    
    $movieResult = $movieStmt->get_result();
    if ($movieResult->num_rows > 0) {
        // Fetch all movies in the selected genre
        $movies = $movieResult->fetch_all(MYSQLI_ASSOC);
    } else {
        // If no movies are found, you can set a message or handle it differently
        $movies = [];
    }

    // Close the prepared statement
    $movieStmt->close();
}

// Close the genre statement
$genreStmt->close();
?>

<!-- HTML Section for displaying genres and movies -->
<section class="genres">
    <div class="container">
        <?php if (!empty($movies)): ?>
        <ul class="movies-list has-scrollbar mt-4">
            <?php 
            $counter = 0;
            foreach ($movies as $movie): 
                if ($counter % 10 == 0 && $counter != 0) {
                    echo '</ul><ul class="movies-list has-scrollbar mt-4">';
                }
            ?>
                <li>
                    <div class="movie-card">
                        <a href="./movie-details.php?movie_id=<?= $movie['movie_id'] ?>">
                            <figure class="card-banner">
                                <img src="./assets/images/posters/poster<?= $movie['movie_id'] ?>.jpg" alt="<?= htmlspecialchars($movie['title']) ?> movie poster">
                            </figure>
                        </a>
                        <div class="title-wrapper">
                            <a href="./movie-details.php?movie_id=<?= $movie['movie_id'] ?>">
                                <h3 class="card-title"><?= htmlspecialchars($movie['title']) ?></h3>
                            </a>
                            <time datetime="<?= $movie['release_year'] ?>"><?= $movie['release_year'] ?></time>
                        </div>
                        <div class="card-meta">
                            <div class="badge badge-outline">
                                <?= $movie['rating'] >= 8 ? 'HD' : '4K' ?>
                            </div>
                            <div class="duration">
                                <ion-icon name="time-outline"></ion-icon>
                                <time datetime="PT<?= $movie['duration'] ?>M"><?= $movie['duration'] ?> min</time>
                            </div>
                            <div class="rating">
                                <ion-icon name="star"></ion-icon>
                                <data><?= $movie['rating'] ?></data>
                            </div>
                        </div>
                    </div>
                </li>
            <?php 
                $counter++;
            endforeach; 
            ?>
        </ul>
        <?php else: ?>
            <p>No movies found for this genre.</p>
        <?php endif; ?>
    </div>
</section>

<?php
// Close the database connection (if not already closed earlier)
$conn->close();
?>
