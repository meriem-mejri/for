<?php
// Database connection
include '../connection/connect.php';

// Check if 'id' is provided in the query string
if (isset($_GET['id']) && is_numeric($_GET['id'])) {
    $movie_id = $_GET['id'];

    // Prepare the delete statement
    $stmt = $conn->prepare("DELETE FROM movies WHERE movie_id = ?");
    $stmt->bind_param('i', $movie_id);

    // Execute the query
    if ($stmt->execute()) {
        // Redirect back to movies.php with a success message
        header("Location: movies.php?success=Movie deleted successfully");
        exit();
    } else {
        // Redirect back with an error message
        header("Location: movies.php?error=Failed to delete movie");
        exit();
    }
} else {
    // Redirect back if 'id' is not set or invalid
    header("Location: movies.php?error=Invalid movie ID");
    exit();
}

// Close the database connection
$conn->close();
?>