<?php
// Database connection
include '../connection/connect.php';

// Fetch all movies
$movies_result = $conn->query("SELECT movies.*, GROUP_CONCAT(genres.genre_name SEPARATOR ', ') AS genres 
    FROM movies
    LEFT JOIN movie_genres ON movies.movie_id = movie_genres.movie_id
    LEFT JOIN genres ON movie_genres.genre_id = genres.genre_id
    GROUP BY movies.movie_id");

$movies = $movies_result->fetch_all(MYSQLI_ASSOC);

// Close the database connection
$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <!-- Boxicons -->
        <link href='https://unpkg.com/boxicons@2.0.9/css/boxicons.min.css' rel='stylesheet'>
        <script src="https://kit.fontawesome.com/48967be5bb.js" crossorigin="anonymous"></script>
        <!-- My CSS -->
        <link rel="stylesheet" href="style.css">
        <link rel="shortcut icon" href="../assets/images/favicon.svg" type="image/svg+xml">
        <title>Movies</title>
    </head>
    <body>
        <!-- SIDEBAR -->
        <section id="sidebar">
            <a href="#" class="brand">
                <img src="../assets/images/favicon.svg" type="image/svg+xml">
                <span class="text">Forja</span>
            </a>
            <ul class="side-menu top">
                <li>
                    <a href="index.php">
                        <i class='bx bxs-dashboard'></i>
                        <span class="text">Dashboard</span>
                    </a>
                </li>
                <li>
                    <a href="genres.php">
                        <i class='bx bxs-category'></i>
                        <span class="text">Genres</span>
                    </a>
                </li>
                <li class="active">
                    <a href="movies.php">
                        <i class='bx bx-movie'></i>
                        <span class="text">Movies</span>
                    </a>
                </li>
                <li>
                    <a href="users.php">
                    <i class='bx bxs-group'></i>
                        <span class="text">Users</span>
                    </a>
                </li>
                <li>
                    <a href="rentals.php">
                        <i class='bx bx-store-alt'></i>
                        <span class="text">Rentals</span>
                    </a>
                </li>
            </ul>
            <ul class="side-menu">
                <li>
                    <a href="logout.php" class="logout">
                        <i class='bx bxs-log-out-circle'></i>
                        <span class="text">Logout</span>
                    </a>
                </li>
            </ul>
        </section>

        <!-- CONTENT -->
        <section id="content">
            <!-- NAVBAR -->
            <nav>
                <i class='bx bx-menu'></i>
                <form action="#">
                    <div class="form-input">
                        <input type="search" placeholder="Search...">
                        <button type="submit" class="search-btn"><i class='bx bx-search'></i></button>
                    </div>
                </form>
                <input type="checkbox" id="switch-mode" hidden>
                <label for="switch-mode" class="switch-mode"></label>
                <a href="#" class="profile">
                <img src="img/admin.jpg">
                </a>
            </nav>

            <!-- MAIN -->
            <main>
                <div class="head-title">
                    <div class="left">
                        <h1>Movies</h1>
                        <ul class="breadcrumb">
                            <li>
                                <a href="movies.php">Dashboard</a>
                            </li>
                            <li><i class='bx bx-chevron-right'></i></li>
                            <li>
                                <a class="active" href="movies.php">Movies</a>
                            </li>
                        </ul>
                    </div>
                </div>
                <div class="movies-container">
                    <div class="movies-header">
                        <h1>Movies List</h1>
                    </div>
                    <table>
                        <thead>
                            <tr>
                                <th>Title</th>
                                <th>Description</th>
                                <th>Release Year</th>
                                <th>Rating</th>
                                <th>Genres</th>
                                <th>Duration</th>
                                <th>Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($movies as $movie): ?>
                                <tr>
                                    <td><?= htmlspecialchars($movie['title']) ?></td>
                                    <td><?= htmlspecialchars(substr($movie['description'], 0, 80)) ?>...</td>
                                    <td><?= htmlspecialchars($movie['release_year']) ?></td>
                                    <td><?= htmlspecialchars($movie['rating']) ?></td>
                                    <td><?= htmlspecialchars($movie['genres'] ?: 'N/A') ?></td>
                                    <td><?= htmlspecialchars($movie['duration']) ?> mins</td>
                                    <td>
                                        <a href="edit_movie.php?id=<?= $movie['movie_id'] ?>" title="Edit">✏️</a>
                                        <a href="delete_movie.php?id=<?= $movie['movie_id'] ?>" title="Delete" onclick="return confirm('Are you sure you want to delete this movie?')">🗑️</a>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                    <h2 style="text-align:center">Add movie <a href="add_movie.php" title="Add Movie">➕</a></h2>
                </div>
            </main>
        </section>
        <script src="script.js"></script>
    </body>
</html>