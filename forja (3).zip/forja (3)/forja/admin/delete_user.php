<?php
// Database connection
include '../connection/connect.php';

// Check if the user ID is provided in the request
if (isset($_GET['id'])) {
    $user_id = intval($_GET['id']);

    // First, delete any rentals associated with the user to maintain database integrity
    $delete_rentals_query = "DELETE FROM rentals WHERE user_id = ?";
    $stmt = $conn->prepare($delete_rentals_query);
    $stmt->bind_param("i", $user_id);
    $stmt->execute();
    $stmt->close();

    // Now delete the user from the users table
    $delete_user_query = "DELETE FROM users WHERE user_id = ?";
    $stmt = $conn->prepare($delete_user_query);
    $stmt->bind_param("i", $user_id);
    $stmt->execute();
    $stmt->close();

    // Close the database connection
    $conn->close();

    // Redirect to the users list page with a success message
    header("Location: users.php?success=User deleted successfully");
    exit;
} else {
    // Redirect to the users list page with an error message
    header("Location: users.php?error=Invalid user ID");
    exit;
}
?>