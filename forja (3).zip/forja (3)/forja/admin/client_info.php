<?php
// Include database connection
include '../connection/connect.php';

// Check if user ID is passed in the URL
if (isset($_GET['id']) && !empty($_GET['id'])) {
    $user_id = $_GET['id'];

    // Fetch user details
    $user_query = "SELECT * FROM users WHERE user_id = ?";
    if ($stmt = $conn->prepare($user_query)) {
        // Bind the user_id parameter
        $stmt->bind_param("i", $user_id);

        // Execute the statement and get the result
        $stmt->execute();
        $result = $stmt->get_result();

        // Check if the user exists
        if ($result->num_rows > 0) {
            $user = $result->fetch_assoc();
        } else {
            echo "User not found.";
            exit();
        }

        // Close the statement
        $stmt->close();
    } else {
        echo "Error fetching user data.";
        exit();
    }

    // Close the database connection
    $conn->close();
} else {
    echo "Invalid user ID.";
    exit();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href='https://unpkg.com/boxicons@2.0.9/css/boxicons.min.css' rel='stylesheet'>
    <script src="https://kit.fontawesome.com/48967be5bb.js" crossorigin="anonymous"></script>
    <title>User Details</title>
    <link rel="stylesheet" href="style.css">
    <link rel="shortcut icon" href="../assets/images/favicon.svg" type="image/svg+xml">
</head>
<body>
    <!-- SIDEBAR -->
    <section id="sidebar">
        <a href="#" class="brand">
            <img src="../assets/images/favicon.svg" type="image/svg+xml">
            <span class="text">Forja</span>
        </a>
        <ul class="side-menu top">
            <li>
                <a href="index.php">
                    <i class='bx bxs-dashboard'></i>
                    <span class="text">Dashboard</span>
                </a>
            </li>
            <li>
                <a href="genres.php">
                    <i class='bx bxs-category'></i>
                    <span class="text">Genres</span>
                </a>
            </li>
            <li>
                <a href="movies.php">
                    <i class='bx bx-movie'></i>
                    <span class="text">Movies</span>
                </a>
            </li>
            <li class="active">
				<a href="users.php">
				<i class='bx bxs-group'></i>
					<span class="text">Users</span>
				</a>
			</li>
            <li>
                <a href="rentals.php">
                    <i class='bx bx-store-alt'></i>
                    <span class="text">Rentals</span>
                </a>
            </li>
        </ul>
        <ul class="side-menu">
            <li>
                <a href="logout.php" class="logout">
                    <i class='bx bxs-log-out-circle'></i>
                    <span class="text">Logout</span>
                </a>
            </li>
        </ul>
    </section>

    <section id="content">
        <!-- NAVBAR -->
        <nav>
            <i class='bx bx-menu'></i>
            <form action="#">
                <div class="form-input">
                    <input type="search" placeholder="Search...">
                    <button type="submit" class="search-btn"><i class='bx bx-search'></i></button>
                </div>
            </form>
            <input type="checkbox" id="switch-mode" hidden>
            <label for="switch-mode" class="switch-mode"></label>
            <a href="#" class="profile">
            <img src="img/admin.jpg">
            </a>
        </nav>

        <main>
            <div class="head-title">
                <div class="left">
                    <h1>Users</h1>
                    <ul class="breadcrumb">
                        <li>
                            <a href="index.php">Dashboard</a>
                        </li>
                        <li><i class='bx bx-chevron-right'></i></li>
                        <li>
                            <a class="active" href="users.php">Users</a>
                        </li>
                    </ul>
                </div>
            </div>
            <div class="form-container">
                <h1>User Details</h1>
                <?php if (isset($user)): ?>
                    <div class="client-info">
                        <p><strong>Username:</strong> <?= htmlspecialchars($user['username']) ?></p>
                        <p><strong>First Name:</strong> <?= htmlspecialchars($user['first_name']) ?></p>
                        <p><strong>Last Name:</strong> <?= htmlspecialchars($user['last_name']) ?></p>
                        <p><strong>Email:</strong> <?= htmlspecialchars($user['email']) ?></p>
                        <p><strong>Phone:</strong> <?= htmlspecialchars($user['phone']) ?></p>
                        <p><strong>Account Created On:</strong> <?= htmlspecialchars($user['date']) ?></p>
                    </div>
                <?php else: ?>
                    <p>User not found.</p>
                <?php endif; ?>
            </div>
        </main>
    </section>
	<script src="script.js"></script>
</body>
</html>
