<?php
// Database connection
include '../connection/connect.php';
$genre_name = $description = "";
$genre_name_err = $description_err = "";

// Process form data when form is submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Validate genre name
    if (empty(trim($_POST["genre_name"]))) {
        $genre_name_err = "Please enter a genre name.";
    } else {
        $genre_name = trim($_POST["genre_name"]);
    }

    // Validate description
    if (empty(trim($_POST["description"]))) {
        $description_err = "Please enter a description.";
    } else {
        $description = trim($_POST["description"]);
    }

    // If no errors, insert data into the database
    if (empty($genre_name_err) && empty($description_err)) {
        // Prepare an insert statement
        $sql = "INSERT INTO genres (genre_name, description) VALUES (?, ?)";

        if ($stmt = $conn->prepare($sql)) {
            // Bind parameters
            $stmt->bind_param("ss", $genre_name, $description);

            // Execute the statement
            if ($stmt->execute()) {
                // Redirect to genres page after successful insertion
                header("location: genres.php");
                exit();
            } else {
                echo "Something went wrong. Please try again later.";
            }

            $stmt->close();
        }
    }

    // Close the database connection
    $conn->close();
}
?>



<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">

	<!-- Boxicons -->
	<link href='https://unpkg.com/boxicons@2.0.9/css/boxicons.min.css' rel='stylesheet'>
	<script src="https://kit.fontawesome.com/48967be5bb.js" crossorigin="anonymous"></script>
	<!-- My CSS -->
	<link rel="stylesheet" href="style.css">
    <link rel="shortcut icon" href="../assets/images/favicon.svg" type="image/svg+xml">
	<title>Add Genre</title>
    
    <style>
        
        /* Title */
        h1 {
            text-align: center;
            font-size: 28px;
            color:  #333;
            margin-bottom: 20px;
        }

        /* Input and Textarea */
        .form-group {
            margin-bottom: 20px;
        }

        .form-group label {
            font-size: 16px;
            margin-bottom: 5px;
            display: block;
        }

        .form-control {
            width: 100%;
            padding: 15px;
            border-radius: 10px;
            border: 1px solid #ddd;
            background: #f9f9f9;
            font-size: 14px;
            transition: border-color 0.3s ease;
        }

        .form-control:focus {
            outline: none;
            border-color: hsl(57, 97%, 45%);
            background:#F9F9F9;
        }

        /* Error message */
        .error {
            color: red;
            font-size: 12px;
        }
        body.dark .form-container {
            background-color: #0C0C1E;
            box-shadow: 0 4px 10px hsl(207, 19%, 11%);
        }

        /* Title */
        body.dark h1 {
            color: #F9F9F9;
        }

        /* Input and Textarea */
        body.dark .form-control {
            background-color:hsl(229, 15%, 21%); 
            border: 1px solid #444;
            color: #fff;
        }
        body.dark .form-group label{color:white;}

        body.dark .form-control:focus {
            border-color: hsl(57, 97%, 45%);
            background: #333;
        }

        /* Error message */
        body.dark .error {
            color: #ff6666;
        }

        /* Dark Mode Toggle Button */
        body.dark .switch-mode {
            background: #1d1f26;
        }

        body.dark .switch-mode::before {
            background: #ffffff;
        }

        /* Adjust the overall body background in dark mode */
        body.dark {
            background-color: #060714;
        }  
    </style>
</head>
<body>
    <!-- SIDEBAR -->
	<section id="sidebar">
        <a href="#" class="brand">
            <img src="../assets/images/favicon.svg" type="image/svg+xml">
            <span class="text">Forja</span>
        </a>
        <ul class="side-menu top">
            <li>
                <a href="index.php">
                    <i class='bx bxs-dashboard'></i>
                    <span class="text">Dashboard</span>
                </a>
            </li>
            <li class="active">
                <a href="genres.php">
                    <i class='bx bxs-category'></i>
                    <span class="text">Genres</span>
                </a>
            </li>
            <li>
                <a href="movies.php">
                    <i class='bx bx-movie'></i>
                    <span class="text">Movies</span>
                </a>
            </li>
            <li>
				<a href="users.php">
				<i class='bx bxs-group'></i>
					<span class="text">Users</span>
				</a>
			</li>
            <li>
                <a href="rentals.php">
                    <i class='bx bx-store-alt'></i>
                    <span class="text">Rentals</span>
                </a>
            </li>
        </ul>
        <ul class="side-menu">
            <li>
                <a href="logout.php" class="logout">
                    <i class='bx bxs-log-out-circle'></i>
                    <span class="text">Logout</span>
                </a>
            </li>
        </ul>
    </section>
	
	<!-- CONTENT -->
	<section id="content">
		<!-- NAVBAR -->
		<nav>
			<i class='bx bx-menu' ></i>
			<form action="#">
				<div class="form-input">
					<input type="search" placeholder="Search...">
					<button type="submit" class="search-btn"><i class='bx bx-search' ></i></button>
				</div>
			</form>
			<input type="checkbox" id="switch-mode" hidden>
			<label for="switch-mode" class="switch-mode"></label>
			
			<a href="#" class="profile">
                <img src="img/admin.jpg">
			</a>
		</nav>

		<!-- MAIN -->
		<main>
			<div class="head-title">
				<div class="left">
					<h1>Genres</h1>
					<ul class="breadcrumb">
						<li>
							<a href="genres.php">Dashboard</a>
						</li>
						<li><i class='bx bx-chevron-right' ></i></li>
						<li>
							<a class="active" href="genres.php">Genres</a>
						</li>
					</ul>
				</div>
			</div>
            <div class="form-container">
                <h1>Add New Genre</h1>
                <form action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" method="POST">

                    <!-- Genre Name -->
                    <div class="form-group">
                        <label for="genre_name">Genre Name</label>
                        <input type="text" id="genre_name" name="genre_name" value="<?php echo $genre_name; ?>" class="form-control">
                        <span class="error"><?php echo $genre_name_err; ?></span>
                    </div>

                    <!-- Description -->
                    <div class="form-group">
                        <label for="description">Description</label>
                        <textarea id="description" name="description" class="form-control"><?php echo $description; ?></textarea>
                        <span class="error"><?php echo $description_err; ?></span>
                    </div>

                    <!-- Submit Button -->
                    <div class="form-group">
                        <button type="submit" class="submit-btn">Add Genre</button>
                    </div>
                </form>
            </div>	
		</main>
	</section>
	<script src="script.js"></script>
</body>
</html>