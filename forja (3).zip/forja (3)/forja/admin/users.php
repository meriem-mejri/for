<?php
// Database connection
include '../connection/connect.php';

// Fetch all users
$users_query = "
    SELECT users.user_id, 
           users.first_name, 
           users.last_name, 
           users.email, 
           users.phone, 
           users.date,
           COUNT(rentals.rental_id) AS rental_count
    FROM users
    LEFT JOIN rentals ON users.user_id = rentals.user_id
    GROUP BY users.user_id
    ORDER BY users.first_name ASC
";

$users_result = $conn->query($users_query);
$users = $users_result->fetch_all(MYSQLI_ASSOC);

// Close the database connection
$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <!-- Boxicons -->
        <link href='https://unpkg.com/boxicons@2.0.9/css/boxicons.min.css' rel='stylesheet'>
        <script src="https://kit.fontawesome.com/48967be5bb.js" crossorigin="anonymous"></script>
        <!-- My CSS -->
        <link rel="stylesheet" href="style.css">
        <link rel="shortcut icon" href="../assets/images/favicon.svg" type="image/svg+xml">
        <title>Users</title>
    </head>
    <body>
        <!-- SIDEBAR -->
        <section id="sidebar">
            <a href="#" class="brand">
                <img src="../assets/images/favicon.svg" type="image/svg+xml">
                <span class="text">Forja</span>
            </a>
            <ul class="side-menu top">
                <li>
                    <a href="index.php">
                        <i class='bx bxs-dashboard'></i>
                        <span class="text">Dashboard</span>
                    </a>
                </li>
                <li>
                    <a href="genres.php">
                        <i class='bx bxs-category'></i>
                        <span class="text">Genres</span>
                    </a>
                </li>
                <li>
                    <a href="movies.php">
                        <i class='bx bx-movie'></i>
                        <span class="text">Movies</span>
                    </a>
                </li>
                <li class="active">
                    <a href="users.php">
                        <i class='bx bxs-group'></i>
                        <span class="text">Users</span>
                    </a>
                </li>
                <li>
                    <a href="rentals.php">
                        <i class='bx bx-store-alt'></i>
                        <span class="text">Rentals</span>
                    </a>
                </li>
            </ul>
            <ul class="side-menu">
                <li>
                    <a href="logout.php" class="logout">
                        <i class='bx bxs-log-out-circle'></i>
                        <span class="text">Logout</span>
                    </a>
                </li>
            </ul>
        </section>

        <!-- CONTENT -->
        <section id="content">
            <!-- NAVBAR -->
            <nav>
                <i class='bx bx-menu'></i>
                <form action="#">
                    <div class="form-input">
                        <input type="search" placeholder="Search...">
                        <button type="submit" class="search-btn"><i class='bx bx-search'></i></button>
                    </div>
                </form>
                <input type="checkbox" id="switch-mode" hidden>
                <label for="switch-mode" class="switch-mode"></label>
                <a href="#" class="profile">
                <img src="img/admin.jpg">
                </a>
            </nav>

            <!-- MAIN -->
            <main>
                <div class="head-title">
                    <div class="left">
                        <h1>Users</h1>
                        <ul class="breadcrumb">
                            <li>
                                <a href="index.php">Dashboard</a>
                            </li>
                            <li><i class='bx bx-chevron-right'></i></li>
                            <li>
                                <a class="active" href="users.php">Users</a>
                            </li>
                        </ul>
                    </div>
                </div>
                <div class="users-container">
                    <div class="users-header">
                        <h1>Users List</h1>
                    </div>
                    <table>
                        <thead>
                            <tr>
                                <th>First Name</th>
                                <th>Last Name</th>
                                <th>Email</th>
                                <th>Phone</th>
                                <th>Account Created</th>
                                <th>Rentals</th>
                                <th>Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($users as $user): ?>
                                <tr>
                                    <td><?= htmlspecialchars($user['first_name']) ?></td>
                                    <td><?= htmlspecialchars($user['last_name']) ?></td>
                                    <td><?= htmlspecialchars($user['email']) ?></td>
                                    <td><?= htmlspecialchars($user['phone']) ?></td>
                                    <td><?= htmlspecialchars($user['date']) ?></td>
                                    <td><?= htmlspecialchars($user['rental_count']) ?></td>
                                    <td>
                                        <a href="client_info.php?id=<?= $user['user_id'] ?>" title="View Info">🔍</a>
                                        <a href="delete_user.php?id=<?= $user['user_id'] ?>" title="Delete" onclick="return confirm('Are you sure you want to delete this user?')">🗑️</a>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            </main>
        </section>
        <script src="script.js"></script>
    </body>
</html>