<?php
// Include database connection
include '../connection/connect.php';

// Check if rental ID is passed in the URL
if (isset($_GET['id']) && !empty($_GET['id'])) {
    $rental_id = $_GET['id'];

    // Fetch the rental details to display in the form
    $rental_query = "
        SELECT rentals.*, 
               users.first_name, 
               users.last_name, 
               users.email, 
               movies.title,
               CASE
                   WHEN rentals.return_date IS NULL THEN DATEDIFF(CURRENT_DATE, rentals.rental_date) * 3
                   ELSE DATEDIFF(rentals.return_date, rentals.rental_date) * 3
               END AS price
        FROM rentals
        INNER JOIN users ON rentals.user_id = users.user_id
        INNER JOIN movies ON rentals.movie_id = movies.movie_id
        WHERE rentals.rental_id = ?
    ";

    if ($stmt = $conn->prepare($rental_query)) {
        // Bind the rental_id parameter
        $stmt->bind_param("i", $rental_id);
        
        // Execute the statement and get the result
        $stmt->execute();
        $result = $stmt->get_result();
        
        // Check if the rental exists
        if ($result->num_rows > 0) {
            $rental = $result->fetch_assoc();
        } else {
            header("Location: rentals.php?message=Rental not found");
            exit();
        }

        // Close the statement
        $stmt->close();
    } else {
        header("Location: rentals.php?message=Error fetching rental data");
        exit();
    }

    // Handle the form submission to update the rental status
    if ($_SERVER['REQUEST_METHOD'] == 'POST') {
        $status = $_POST['status'];

        // Prepare the UPDATE query for status only
        $update_query = "UPDATE rentals SET status = ? WHERE rental_id = ?";
        if ($stmt = $conn->prepare($update_query)) {
            // Bind the parameters
            $stmt->bind_param("si", $status, $rental_id);

            // Execute the update query
            if ($stmt->execute()) {
                header("Location: rentals.php?message=Rental status updated successfully");
                exit();
            } else {
                $error_message = "Error updating rental status";
            }

            // Close the statement
            $stmt->close();
        } else {
            $error_message = "Error preparing the update query";
        }
    }

    // Close the database connection
    $conn->close();
} else {
    header("Location: rentals.php?message=Invalid rental ID");
    exit();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href='https://unpkg.com/boxicons@2.0.9/css/boxicons.min.css' rel='stylesheet'>
    <script src="https://kit.fontawesome.com/48967be5bb.js" crossorigin="anonymous"></script>
    <title>Edit Rental</title>
    <link rel="stylesheet" href="style.css">
    <link rel="shortcut icon" href="../assets/images/favicon.svg" type="image/svg+xml">
</head>
<body>
    <!-- SIDEBAR -->
    <section id="sidebar">
        <a href="#" class="brand">
            <img src="../assets/images/favicon.svg" type="image/svg+xml">
            <span class="text">Forja</span>
        </a>
        <ul class="side-menu top">
            <li>
                <a href="index.php">
                    <i class='bx bxs-dashboard'></i>
                    <span class="text">Dashboard</span>
                </a>
            </li>
            <li>
                <a href="genres.php">
                    <i class='bx bxs-category'></i>
                    <span class="text">Genres</span>
                </a>
            </li>
            <li>
                <a href="movies.php">
                    <i class='bx bx-movie'></i>
                    <span class="text">Movies</span>
                </a>
            </li>
            <li>
				<a href="users.php">
				<i class='bx bxs-group'></i>
					<span class="text">Users</span>
				</a>
			</li>
            <li class="active">
                <a href="rentals.php">
                    <i class='bx bx-store-alt'></i>
                    <span class="text">Rentals</span>
                </a>
            </li>
        </ul>
        <ul class="side-menu">
            <li>
                <a href="logout.php" class="logout">
                    <i class='bx bxs-log-out-circle'></i>
                    <span class="text">Logout</span>
                </a>
            </li>
        </ul>
    </section>

    <!-- CONTENT -->
    <section id="content">
        <!-- NAVBAR -->
        <nav>
            <i class='bx bx-menu'></i>
            <form action="#">
                <div class="form-input">
                    <input type="search" placeholder="Search...">
                    <button type="submit" class="search-btn"><i class='bx bx-search'></i></button>
                </div>
            </form>
            <input type="checkbox" id="switch-mode" hidden>
            <label for="switch-mode" class="switch-mode"></label>
            <a href="#" class="profile">
                <img src="img/admin.jpg">
            </a>
        </nav>

        <!-- MAIN -->
        <main>
            <div class="head-title">
                <div class="left">
                    <h1>Rentals</h1>
                    <ul class="breadcrumb">
                        <li>
                            <a href="rentals.php">Dashboard</a>
                        </li>
                        <li><i class='bx bx-chevron-right'></i></li>
                        <li>
                            <a class="active" href="rentals.php">Rentals</a>
                        </li>
                    </ul>
                </div>
            </div>
            <div class="form-container">
                <h1>Edit Rental</h1>
                <?php if (isset($error_message)): ?>
                    <div class="error-message"><?= htmlspecialchars($error_message) ?></div>
                <?php endif; ?>

                <div class="rental-details">
                    <h2>Rental Details</h2>
                    <p><strong>Rental ID:</strong> <?= htmlspecialchars($rental['rental_id']) ?></p>
                    <p><strong>Movie Title:</strong> <?= htmlspecialchars($rental['title']) ?></p>
                    <p><strong>Client Name:</strong> <?= htmlspecialchars($rental['first_name'] . ' ' . $rental['last_name']) ?></p>
                    <p><strong>Client Email:</strong> <?= htmlspecialchars($rental['email']) ?></p>
                    <p><strong>Rental Date:</strong> <?= htmlspecialchars($rental['rental_date']) ?></p>
                    <p><strong>Return Date:</strong> <?= htmlspecialchars($rental['return_date'] ?: 'N/A') ?></p>
                    <p><strong>Status:</strong> <?= ucfirst(htmlspecialchars($rental['status'])) ?></p>
                    <p><strong>Price:</strong> <?= number_format($rental['price'], 2) ?> DT</p>
                </div>
                    <br>
                <form action="edit_rental.php?id=<?= $rental['rental_id'] ?>" method="POST">
                    <label for="status">Update Status:</label>
                    <select name="status" required>
                        <option value="pending" <?= $rental['status'] == 'pending' ? 'selected' : '' ?>>Pending</option>
                        <option value="rented" <?= $rental['status'] == 'rented' ? 'selected' : '' ?>>Rented</option>
                        <option value="returned" <?= $rental['status'] == 'returned' ? 'selected' : '' ?>>Returned</option>
                        <option value="overdue" <?= $rental['status'] == 'overdue' ? 'selected' : '' ?>>Overdue</option>
                    </select>
                    <br><br>
                    <button type="submit" class="submit-btn">Update Status</button>
                </form>
            </div>
        </main>
    </section>
	<script src="script.js"></script>
</body>
</html>