<?php
// Database connection
include '../connection/connect.php';

// Update rentals to 'Overdue' if the conditions are met
$update_status_query = "
    UPDATE rentals
    SET status = 'Overdue'
    WHERE return_date IS NOT NULL 
      AND return_date < NOW() 
      AND status IN ('pending', 'rented')
";
mysqli_query($conn, $update_status_query);

// Fetch all rentals with user, movie details, and calculated dynamic status and price
$rentals_query = "
    SELECT rentals.*, 
           users.first_name, 
           users.last_name, 
           users.email, 
           movies.title,
           CASE
               WHEN rentals.return_date IS NOT NULL AND rentals.return_date < NOW() AND rentals.status IN ('pending', 'rented') THEN 'Overdue'
               ELSE rentals.status
           END AS dynamic_status,
           CASE
               WHEN rentals.return_date IS NULL THEN DATEDIFF(CURRENT_DATE, rentals.rental_date) * 3
               ELSE DATEDIFF(rentals.return_date, rentals.rental_date) * 3
           END AS price
    FROM rentals
    INNER JOIN users ON rentals.user_id = users.user_id
    INNER JOIN movies ON rentals.movie_id = movies.movie_id
    ORDER BY rentals.rental_date DESC
";

$rentals_result = $conn->query($rentals_query);
$rentals = $rentals_result->fetch_all(MYSQLI_ASSOC);

// Close the database connection
$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <!-- Boxicons -->
        <link href='https://unpkg.com/boxicons@2.0.9/css/boxicons.min.css' rel='stylesheet'>
        <script src="https://kit.fontawesome.com/48967be5bb.js" crossorigin="anonymous"></script>
        <!-- My CSS -->
        <link rel="stylesheet" href="style.css">
        <link rel="shortcut icon" href="../assets/images/favicon.svg" type="image/svg+xml">
        <title>Rentals</title>
    </head>
    <body>
        <!-- SIDEBAR -->
        <section id="sidebar">
            <a href="#" class="brand">
                <img src="../assets/images/favicon.svg" type="image/svg+xml">
                <span class="text">Forja</span>
            </a>
            <ul class="side-menu top">
                <li>
                    <a href="index.php">
                        <i class='bx bxs-dashboard'></i>
                        <span class="text">Dashboard</span>
                    </a>
                </li>
                <li>
                    <a href="genres.php">
                        <i class='bx bxs-category'></i>
                        <span class="text">Genres</span>
                    </a>
                </li>
                <li>
                    <a href="movies.php">
                        <i class='bx bx-movie'></i>
                        <span class="text">Movies</span>
                    </a>
                </li>
                <li>
                    <a href="users.php">
                        <i class='bx bxs-group'></i>
                        <span class="text">Users</span>
                    </a>
                </li>
                <li class="active">
                    <a href="rentals.php">
                        <i class='bx bx-store-alt'></i>
                        <span class="text">Rentals</span>
                    </a>
                </li>
            </ul>
            <ul class="side-menu">
                <li>
                    <a href="logout.php" class="logout">
                        <i class='bx bxs-log-out-circle'></i>
                        <span class="text">Logout</span>
                    </a>
                </li>
            </ul>
        </section>

        <!-- CONTENT -->
        <section id="content">
            <!-- NAVBAR -->
            <nav>
                <i class='bx bx-menu'></i>
                <form action="#">
                    <div class="form-input">
                        <input type="search" placeholder="Search...">
                        <button type="submit" class="search-btn"><i class='bx bx-search'></i></button>
                    </div>
                </form>
                <input type="checkbox" id="switch-mode" hidden>
                <label for="switch-mode" class="switch-mode"></label>
                <a href="#" class="profile">
                <img src="img/admin.jpg">
                </a>
            </nav>

            <!-- MAIN -->
            <main>
                <div class="head-title">
                    <div class="left">
                        <h1>Rentals</h1>
                        <ul class="breadcrumb">
                            <li>
                                <a href="rentals.php">Dashboard</a>
                            </li>
                            <li><i class='bx bx-chevron-right'></i></li>
                            <li>
                                <a class="active" href="rentals.php">Rentals</a>
                            </li>
                        </ul>
                    </div>
                </div>
                <div class="rentals-container">
                    <div class="rentals-header">
                        <h1>Rentals List</h1>
                    </div>
                    <table>
                        <thead>
                            <tr>
                                <th>Movie Title</th>
                                <th>User</th>
                                <th>Email</th>
                                <th>Rental Date</th>
                                <th>Return Date</th>
                                <th>Status</th>
                                <th>Price (DT)</th>
                                <th>Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($rentals as $rental): ?>
                                <tr>
                                    <td><?= htmlspecialchars($rental['title']) ?></td>
                                    <td><?= htmlspecialchars($rental['first_name'] . ' ' . $rental['last_name']) ?></td>
                                    <td><?= htmlspecialchars($rental['email']) ?></td>
                                    <td><?= htmlspecialchars($rental['rental_date']) ?></td>
                                    <td><?= htmlspecialchars($rental['return_date'] ?: 'N/A') ?></td>
                                    <td><?= htmlspecialchars(ucfirst($rental['dynamic_status'])) ?></td>
                                    <td><?= number_format($rental['price']) ?> DT</td>
                                    <td>
                                        <a href="edit_rental.php?id=<?= $rental['rental_id'] ?>" title="Edit">✏️</a>
                                        <a href="delete_rental.php?id=<?= $rental['rental_id'] ?>" title="Delete" onclick="return confirm('Are you sure you want to delete this rental?')">🗑️</a>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            </main>
        </section>
        <script src="script.js"></script>
    </body>
</html>
