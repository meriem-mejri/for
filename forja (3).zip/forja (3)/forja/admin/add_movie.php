<?php
// Database connection
include '../connection/connect.php';

// Fetch all genres for the dropdown
$genres_query = "SELECT * FROM genres";
$genres_result = $conn->query($genres_query);
$genres = $genres_result->fetch_all(MYSQLI_ASSOC);

// Handle form submission
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $title = $_POST['title'];
    $description = $_POST['description'];
    $release_year = $_POST['release_year'];
    $rating = $_POST['rating'];
    $trailer = $_POST['trailer'];
    $poster = $_POST['poster'];
    $duration = $_POST['duration'];
    $selected_genres = $_POST['genres'] ?? [];

    // Insert movie into the `movies` table
    $stmt = $conn->prepare("INSERT INTO movies (title, description, release_year, rating, trailer, poster, duration) VALUES (?, ?, ?, ?, ?, ?, ?)");
    $stmt->bind_param('ssidsii', $title, $description, $release_year, $rating, $trailer, $poster, $duration);

    if ($stmt->execute()) {
        $movie_id = $conn->insert_id;

        // Insert selected genres into `movie_genres`
        $genre_stmt = $conn->prepare("INSERT INTO movie_genres (movie_id, genre_id) VALUES (?, ?)");
        foreach ($selected_genres as $genre_id) {
            $genre_stmt->bind_param('ii', $movie_id, $genre_id);
            $genre_stmt->execute();
        }

        // Redirect to movies.php with a success message
        header("Location: movies.php?success=Movie added successfully");
        exit();
    } else {
        $error = "Error adding movie: " . $conn->error;
    }
}

// Close database connection
$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <!-- Boxicons -->
        <link href='https://unpkg.com/boxicons@2.0.9/css/boxicons.min.css' rel='stylesheet'>
        <script src="https://kit.fontawesome.com/48967be5bb.js" crossorigin="anonymous"></script>
        <!-- My CSS -->
        <link rel="stylesheet" href="style.css">
        <link rel="shortcut icon" href="../assets/images/favicon.svg" type="image/svg+xml">
        <title>Add Movie</title>
    </head>
    <body>
        <!-- SIDEBAR -->
        <section id="sidebar">
            <a href="#" class="brand">
                <img src="../assets/images/favicon.svg" type="image/svg+xml">
                <span class="text">Forja</span>
            </a>
            <ul class="side-menu top">
                <li>
                    <a href="index.php">
                        <i class='bx bxs-dashboard'></i>
                        <span class="text">Dashboard</span>
                    </a>
                </li>
                <li>
                    <a href="genres.php">
                        <i class='bx bxs-category'></i>
                        <span class="text">Genres</span>
                    </a>
                </li>
                <li class="active">
                    <a href="movies.php">
                        <i class='bx bx-movie'></i>
                        <span class="text">Movies</span>
                    </a>
                </li>
                <li>
                    <a href="users.php">
                    <i class='bx bxs-group'></i>
                        <span class="text">Users</span>
                    </a>
                </li>
                <li>
                    <a href="rentals.php">
                        <i class='bx bx-store-alt'></i>
                        <span class="text">Rentals</span>
                    </a>
                </li>
            </ul>
            <ul class="side-menu">
                <li>
                    <a href="logout.php" class="logout">
                        <i class='bx bxs-log-out-circle'></i>
                        <span class="text">Logout</span>
                    </a>
                </li>
            </ul>
        </section>
        
        <section id="content">
            <!-- NAVBAR -->
            <nav>
                <i class='bx bx-menu'></i>
                <form action="#">
                    <div class="form-input">
                        <input type="search" placeholder="Search...">
                        <button type="submit" class="search-btn"><i class='bx bx-search'></i></button>
                    </div>
                </form>
                <input type="checkbox" id="switch-mode" hidden>
                <label for="switch-mode" class="switch-mode"></label>
                <a href="#" class="profile">
                    <img src="img/admin.jpg">
                </a>
            </nav>

            <main>
                <div class="head-title">
                    <div class="left">
                        <h1>Movies</h1>
                        <ul class="breadcrumb">
                            <li>
                                <a href="movies.php">Dashboard</a>
                            </li>
                            <li><i class='bx bx-chevron-right'></i></li>
                            <li>
                                <a class="active" href="movies.php">Movies</a>
                            </li>
                        </ul>
                    </div>
                </div>
                <div class="form-container">
                    <h1>Add New Movie</h1>
                    <form action="add_movie.php" method="POST">
                        <div class="form-group">
                            <label for="title">Movie Title</label>
                            <input type="text" name="title" id="title" required>
                        </div>
                        <div class="form-group">
                            <label for="description">Description</label>
                            <textarea name="description" id="description" rows="4" required></textarea>
                        </div>
                        <div class="form-group">
                            <label for="release_year">Release Year</label>
                            <input type="number" name="release_year" id="release_year" min="1900" max="<?= date('Y') ?>" required>
                        </div>
                        <div class="form-group">
                            <label for="rating">Rating</label>
                            <input type="number" name="rating" id="rating" step="0.1" min="0" max="10" required>
                        </div>
                        <div class="form-group">
                            <label for="trailer">Upload Trailer</label>
                            <input type="file" name="trailer" id="trailer" accept="video/*" required>
                        </div>
                        <div class="form-group">
                            <label for="poster">Upload Poster</label>
                            <input type="file" name="poster" id="poster" accept="image/*" required>
                            <img id="poster-preview" src="../assets/images/posters/<?= htmlspecialchars($movie['poster']) ?>" alt="Poster Preview" style="max-width: 200px; display: block;">
                        </div>
                        <div class="form-group">
                            <label for="duration">Duration (in minutes)</label>
                            <input type="number" name="duration" id="duration" required>
                        </div>
                        <div class="form-group">
                            <label for="genres">Genres</label>
                            <div id="genres" class="genre-grid">
                                <?php foreach ($genres as $genre): ?>
                                    <div class="genre-item">
                                        <input 
                                            type="checkbox" 
                                            name="genres[]" 
                                            value="<?= htmlspecialchars($genre['genre_id']) ?>" 
                                            id="genre_<?= htmlspecialchars($genre['genre_id']) ?>"
                                        >
                                        <label for="genre_<?= htmlspecialchars($genre['genre_id']) ?>">
                                            <?= htmlspecialchars($genre['genre_name']) ?>
                                        </label>
                                    </div>
                                <?php endforeach; ?>
                            </div>
                        </div>
                        <button type="submit" class="submit-btn">Add Movie</button>
                        <?php if (isset($error)): ?>
                            <p class="error"><?= htmlspecialchars($error) ?></p>
                        <?php endif; ?>
                    </form>
                </div>
            </main>
        </section>
        <script>
            // Preview poster when selected
            const posterInput = document.getElementById('poster');
            const posterPreview = document.getElementById('poster-preview');
            posterInput.addEventListener('change', () => {
                const file = posterInput.files[0];
                if (file) {
                    posterPreview.src = URL.createObjectURL(file);
                    posterPreview.style.display = 'block';
                }
            });
        </script>
	    <script src="script.js"></script>
    </body>
</html>