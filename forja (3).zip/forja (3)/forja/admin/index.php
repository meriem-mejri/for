



<?php
// Database connection
include '../connection/connect.php';

// Query to count rows in the 'rentals' table
$result = $conn->query("SELECT COUNT(*) AS total FROM rentals");
$row = $result->fetch_assoc();
$totalRentals = $row['total'];

$result = $conn->query("SELECT COUNT(*) AS total FROM users");
$row = $result->fetch_assoc();
$totalUsers = $row['total'];

// Close the database connection


$result = $conn->query("
    SELECT SUM(DATEDIFF(return_date, rental_date) * 3) AS total_sales 
    FROM rentals
    WHERE return_date IS NOT NULL
");
$row = $result->fetch_assoc();
$totalSales = $row['total_sales'] ?? 0;
$result = $conn->query("SELECT COUNT(*) AS total FROM movies");
$row = $result->fetch_assoc();
$totalMovies = $row['total'];

$result = $conn->query("SELECT COUNT(*) AS total FROM genres");
$row = $result->fetch_assoc();
$totalGenres = $row['total'];
$conn->close();
?>



<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">

	<!-- Boxicons -->
	<link href='https://unpkg.com/boxicons@2.0.9/css/boxicons.min.css' rel='stylesheet'>
	<script src="https://kit.fontawesome.com/48967be5bb.js" crossorigin="anonymous"></script>
	<!-- My CSS -->
	<link rel="stylesheet" href="style.css">
    <link rel="shortcut icon" href="../assets/images/favicon.svg" type="image/svg+xml">
	<title>Dashboard</title>
</head>
<body>


	<!-- SIDEBAR -->
	<section id="sidebar">
		<a href="#" class="brand">
		<img src="../assets/images/favicon.svg"  type="image/svg+xml" >
			<span class="text">Forja</span>
		</a>
		<ul class="side-menu top">
			<li class="active">
				<a href="#">
					<i class='bx bxs-dashboard' ></i>
					<span class="text">Dashboard</span>
				</a>
			</li>
			<li>
				<a href="genres.php">
				<i class='bx bxs-category'></i>
					<span class="text">Genres</span>
				</a>
			</li>
			<li>
				<a href="movies.php">
				<i class='bx bx-movie'></i>
					<span class="text">Movies</span>
				</a>
			</li>
			<li>
				<a href="users.php">
				<i class='bx bxs-group'></i>
					<span class="text">Users</span>
				</a>
			</li>
			<li>
				<a href="rentals.php">
				<i class='bx bx-store-alt'></i>
					<span class="text">Rentals</span>
				</a>
			</li>
			
		</ul>
		<ul class="side-menu">
			
			<li>
				<a href="logout.php" class="logout">
					<i class='bx bxs-log-out-circle' ></i>
					<span class="text">Logout</span>
				</a>
			</li>
		</ul>
	</section>
	<!-- SIDEBAR -->

	<!-- CONTENT -->
	<section id="content">
		<!-- NAVBAR -->
		<nav>
			<i class='bx bx-menu' ></i>
			<form action="#">
				<div class="form-input">
					<input type="search" placeholder="Search...">
					<button type="submit" class="search-btn"><i class='bx bx-search' ></i></button>
				</div>
			</form>
			<input type="checkbox" id="switch-mode" hidden>
			<label for="switch-mode" class="switch-mode"></label>
			
			<a href="#" class="profile">
				<img src="img/admin.jpg">
			</a>
		</nav>
		<!-- NAVBAR -->

		<!-- MAIN -->
		<main>
			<div class="head-title">
				<div class="left">
					<h1>Dashboard</h1>
					<ul class="breadcrumb">
						<li>
							<a href="#">Dashboard</a>
						</li>
						<li><i class='bx bx-chevron-right' ></i></li>
						<li>
							<a class="active" href="#">Home</a>
						</li>
					</ul>
				</div>
				
			</div>

			<ul class="box-info">
				<li>
					<i class='bx bxs-calendar-check' ></i>
					<span class="text">
					<h3><?php echo $totalRentals; ?></h3>
						<p>Rentals</p>
					</span>
				</li>
				<li>
					<i class='bx bxs-group' ></i>
					<span class="text">
					<h3><?php echo $totalUsers; ?></h3>
						<p>Users</p>
					</span>
				</li>
				<li>
					<i class='bx bxs-dollar-circle' ></i>
					<span class="text">
					<h3><?php echo $totalSales; ?></h3>
						<p>Total Sales</p>
					</span>
					
				</li>
				<li>
				<i class='bx bx-movie'></i>
					<span class="text">
					<h3><?php echo $totalMovies; ?></h3>
						<p>Movies</p>
					</span>
					
				</li>
				<li>
				<i class='bx bxs-category'></i>
					<span class="text">
					<h3><?php echo $totalGenres; ?></h3>
						<p>Genres</p>
					</span>
					
				</li>
			</ul>
		</main>
		<!-- MAIN -->
	</section>
	<!-- CONTENT -->
		<script src="script.js"></script>
</body>
</html>