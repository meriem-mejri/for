<?php
// Include the database connection
include '../connection/connect.php';

// Check if the genre_id is passed in the URL
if (isset($_GET['id'])) {
    $genre_id = $_GET['id']; // Get genre_id from the URL

    // Prepare and execute the delete query
    $delete_query = "DELETE FROM genres WHERE genre_id = ?";
    $delete_stmt = $conn->prepare($delete_query);
    $delete_stmt->bind_param('i', $genre_id); // Bind the genre_id to the query
    $delete_stmt->execute();

    // Check if a row was deleted
    if ($delete_stmt->affected_rows > 0) {
        // Genre was deleted successfully
        echo "<script>alert('Genre deleted successfully!'); window.location.href='genres.php';</script>";
    } else {
        // Genre not found or failed to delete
        echo "<script>alert('Genre deleted successfully!'); window.location.href='genres.php';</script>";
    }

    // Close the statement and connection
    $delete_stmt->close();
} else {
    // If genre_id is not passed, show an error
    echo "<script>alert('Error: Genre ID is missing!'); window.location.href='genres.php';</script>";
}

// Close the database connection
$conn->close();
?>
