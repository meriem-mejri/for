<?php
// Database connection
include '../connection/connect.php';
// Check if the genre_id is set in the URL (use 'id' instead of 'genre_id')
if (isset($_GET['id'])) {
    $genre_id = $_GET['id']; // Get the genre_id from the URL

    // Fetch genre details from the database
    $query = "SELECT genre_id, genre_name, description FROM genres WHERE genre_id = ?";
    $stmt = $conn->prepare($query);
    $stmt->bind_param('i', $genre_id); // Bind the genre_id to the prepared statement
    $stmt->execute();
    $stmt->store_result();
    $stmt->bind_result($genre_id, $genre_name, $description);
    $stmt->fetch();
} else {
    echo "Genre ID is missing!";
    exit;
}

// Handle form submission to update the genre
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $updated_genre_name = trim($_POST['genre_name']);
    $updated_description = trim($_POST['description']);

    // Update the genre in the database
    $update_query = "UPDATE genres SET genre_name = ?, description = ? WHERE genre_id = ?";
    $update_stmt = $conn->prepare($update_query);
    $update_stmt->bind_param('ssi', $updated_genre_name, $updated_description, $genre_id);
    $update_stmt->execute();

    // Redirect to the genres list page after successful update
    echo "<script>alert('Genre updated successfully!'); window.location.href='genres.php';</script>";
}


// Handle form submission to update the genre
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $updated_genre_name = trim($_POST['genre_name']);
    $updated_description = trim($_POST['description']);

    // Update the genre in the database
    $update_query = "UPDATE genres SET genre_name = ?, description = ? WHERE genre_id = ?";
    $update_stmt = $conn->prepare($update_query);
    $update_stmt->bind_param('ssi', $updated_genre_name, $updated_description, $genre_id);
    $update_stmt->execute();

    // Redirect to the genres list page after successful update
    echo "<script>alert('Genre updated successfully!'); window.location.href='genres.php';</script>";
}
?>


<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">

	<!-- Boxicons -->
	<link href='https://unpkg.com/boxicons@2.0.9/css/boxicons.min.css' rel='stylesheet'>
	<script src="https://kit.fontawesome.com/48967be5bb.js" crossorigin="anonymous"></script>
	<!-- My CSS -->
	<link rel="stylesheet" href="style.css">
    <link rel="shortcut icon" href="../assets/images/favicon.svg" type="image/svg+xml">
	<title>Edit Genre</title>
</head>
<body>
<style>
        /* Global Styles */
    

        /* Form Container */
        .form-container {
            background-color: #F9F9F9;
            padding: 40px 60px;
            margin-top: 30px;
            margin-left: 70px;
            border-radius: 15px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
            width: 900px;
            transition: background-color 0.3s ease;
        }


        /* Title */
        h1 {
            text-align: center;
            font-size: 28px;
            color:  #333;
            margin-bottom: 20px;
        }

        /* Input and Textarea */
        .form-group {
            margin-bottom: 20px;
        }

        .form-group label {
            font-size: 16px;
            margin-bottom: 5px;
            display: block;
        }

        .form-control {
            width: 100%;
            padding: 15px;
            border-radius: 10px;
            border: 1px solid #ddd;
            background: #f9f9f9;
            font-size: 14px;
            transition: border-color 0.3s ease;
        }

        .form-control:focus {
            outline: none;
            border-color: hsl(57, 97%, 45%);
            background:#F9F9F9;
        }

        /* Error message */
        .error {
            color: red;
            font-size: 12px;
        }

        body.dark .form-container {
            background-color: #0C0C1E;
            box-shadow: 0 4px 10px hsl(207, 19%, 11%);
        }

/* Title */
body.dark h1 {
    color: #F9F9F9;
}

/* Input and Textarea */
body.dark .form-control {
    background-color:hsl(229, 15%, 21%); 
    border: 1px solid #444;
    color: #fff;
}
body.dark .form-group label{color:white;}

body.dark .form-control:focus {
    border-color: hsl(57, 97%, 45%);
    background: #333;
}

/* Error message */
body.dark .error {
    color: #ff6666;
}

/* Dark Mode Toggle Button */
body.dark .switch-mode {
    background: #1d1f26;
}

body.dark .switch-mode::before {
    background: #ffffff;
}

/* Adjust the overall body background in dark mode */
body.dark {
    background-color: #060714;
}        
    </style>

	<!-- SIDEBAR -->
	<section id="sidebar">
        <a href="#" class="brand">
            <img src="../assets/images/favicon.svg" type="image/svg+xml">
            <span class="text">Forja</span>
        </a>
        <ul class="side-menu top">
            <li>
                <a href="index.php">
                    <i class='bx bxs-dashboard'></i>
                    <span class="text">Dashboard</span>
                </a>
            </li>
            <li class="active">
                <a href="genres.php">
                    <i class='bx bxs-category'></i>
                    <span class="text">Genres</span>
                </a>
            </li>
            <li>
                <a href="movies.php">
                    <i class='bx bx-movie'></i>
                    <span class="text">Movies</span>
                </a>
            </li>
            <li>
				<a href="users.php">
				<i class='bx bxs-group'></i>
					<span class="text">Users</span>
				</a>
			</li>
            <li>
                <a href="rentals.php">
                    <i class='bx bx-store-alt'></i>
                    <span class="text">Rentals</span>
                </a>
            </li>
        </ul>
        <ul class="side-menu">
            <li>
                <a href="logout.php" class="logout">
                    <i class='bx bxs-log-out-circle'></i>
                    <span class="text">Logout</span>
                </a>
            </li>
        </ul>
    </section>
	<!-- SIDEBAR -->



	<!-- CONTENT -->
	<section id="content">
		<!-- NAVBAR -->
		<nav>
			<i class='bx bx-menu' ></i>
			<form action="#">
				<div class="form-input">
					<input type="search" placeholder="Search...">
					<button type="submit" class="search-btn"><i class='bx bx-search' ></i></button>
				</div>
			</form>
			<input type="checkbox" id="switch-mode" hidden>
			<label for="switch-mode" class="switch-mode"></label>
			
			<a href="#" class="profile">
                <img src="img/admin.jpg">
			</a>
		</nav>
		<!-- NAVBAR -->

		<!-- MAIN -->
		<main>
			<div class="head-title">
				<div class="left">
					<h1>Genres</h1>
					<ul class="breadcrumb">
						<li>
							<a href="genres.php">Dashboard</a>
						</li>
						<li><i class='bx bx-chevron-right' ></i></li>
						<li>
							<a class="active" href="genres.php">Genres</a>
						</li>
					</ul>
				</div>
				
			</div>
            <div class="form-container">
    <h1>Edit Genre</h1>
    <form action="edit_genre.php?id=<?php echo $genre_id; ?>" method="POST">

        <!-- Genre Name -->
        <div class="form-group">
            <label for="genre_name">Genre Name</label>
            <input type="text" id="genre_name" name="genre_name" value="<?php echo $genre_name; ?>" class="form-control">
           
        </div>

        <!-- Description -->
        <div class="form-group">
            <label for="description">Description</label>
            <textarea id="description" name="description" class="form-control"><?php echo $description; ?></textarea>
           
        </div>

        <!-- Submit Button -->
        <div class="form-group">
            <button type="submit" class="submit-btn">Update Genre</button>
        </div>

    </form>
</div>



			


			
			
		</main>
		<!-- MAIN -->
	</section>
	<!-- CONTENT -->
	

	<script src="script.js"></script>
</body>
</html>