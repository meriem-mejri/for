<?php
// Database connection
include '../connection/connect.php';

// Check if the movie ID is provided
if (isset($_GET['id']) && is_numeric($_GET['id'])) {
    $movie_id = $_GET['id'];

    // Fetch the movie details
    $movie_query = $conn->prepare("SELECT * FROM movies WHERE movie_id = ?");
    $movie_query->bind_param('i', $movie_id);
    $movie_query->execute();
    $movie_result = $movie_query->get_result();

    if ($movie_result->num_rows > 0) {
        $movie = $movie_result->fetch_assoc();
    } else {
        header("Location: movies.php?error=Movie not found");
        exit();
    }

    // Fetch all genres for the checkboxes
    $genres_query = "SELECT * FROM genres";
    $genres_result = $conn->query($genres_query);
    $genres = $genres_result->fetch_all(MYSQLI_ASSOC);

    // Fetch selected genres for the movie
    $selected_genres_query = $conn->prepare("SELECT genre_id FROM movie_genres WHERE movie_id = ?");
    $selected_genres_query->bind_param('i', $movie_id);
    $selected_genres_query->execute();
    $selected_genres_result = $selected_genres_query->get_result();
    $selected_genres = array_column($selected_genres_result->fetch_all(MYSQLI_ASSOC), 'genre_id');
} else {
    header("Location: movies.php?error=Invalid movie ID");
    exit();
}

// Handle form submission
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $title = $_POST['title'];
    $description = $_POST['description'];
    $release_year = $_POST['release_year'];
    $rating = $_POST['rating'];
    $trailer = $_POST['trailer'];
    $poster = $_POST['poster'];
    $duration = $_POST['duration'];
    $updated_genres = $_POST['genres'] ?? [];

    // Update movie details
    $update_movie = $conn->prepare("UPDATE movies SET title = ?, description = ?, release_year = ?, rating = ?, trailer = ?, poster = ?, duration = ? WHERE movie_id = ?");
    $update_movie->bind_param('ssidsiii', $title, $description, $release_year, $rating, $trailer, $poster, $duration, $movie_id);

    if ($update_movie->execute()) {
        // Update genres
        $conn->query("DELETE FROM movie_genres WHERE movie_id = $movie_id");
        $genre_stmt = $conn->prepare("INSERT INTO movie_genres (movie_id, genre_id) VALUES (?, ?)");
        foreach ($updated_genres as $genre_id) {
            $genre_stmt->bind_param('ii', $movie_id, $genre_id);
            $genre_stmt->execute();
        }

        // Redirect with success message
        header("Location: movies.php?success=Movie updated successfully");
        exit();
    } else {
        $error = "Error updating movie: " . $conn->error;
    }
}

// Close the database connection
$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href='https://unpkg.com/boxicons@2.0.9/css/boxicons.min.css' rel='stylesheet'>
    <link rel="stylesheet" href="style.css">
    <link rel="shortcut icon" href="../assets/images/favicon.svg" type="image/svg+xml">
    <title>Edit Movie</title>
</head>
<body>
    <!-- SIDEBAR -->
    <section id="sidebar">
        <a href="#" class="brand">
            <img src="../assets/images/favicon.svg" type="image/svg+xml">
            <span class="text">Forja</span>
        </a>
        <ul class="side-menu top">
            <li>
                <a href="index.php">
                    <i class='bx bxs-dashboard'></i>
                    <span class="text">Dashboard</span>
                </a>
            </li>
            <li>
                <a href="genres.php">
                    <i class='bx bxs-category'></i>
                    <span class="text">Genres</span>
                </a>
            </li>
            <li class="active">
                <a href="movies.php">
                    <i class='bx bx-movie'></i>
                    <span class="text">Movies</span>
                </a>
            </li>
            <li>
				<a href="users.php">
				<i class='bx bxs-group'></i>
					<span class="text">Users</span>
				</a>
			</li>
            <li>
                <a href="rentals.php">
                    <i class='bx bx-store-alt'></i>
                    <span class="text">Rentals</span>
                </a>
            </li>
        </ul>
        <ul class="side-menu">
            <li>
                <a href="logout.php" class="logout">
                    <i class='bx bxs-log-out-circle'></i>
                    <span class="text">Logout</span>
                </a>
            </li>
        </ul>
    </section>

    <section id="content">
        <!-- NAVBAR -->
        <nav>
            <i class='bx bx-menu'></i>
            <form action="#">
                <div class="form-input">
                    <input type="search" placeholder="Search...">
                    <button type="submit" class="search-btn"><i class='bx bx-search'></i></button>
                </div>
            </form>
            <input type="checkbox" id="switch-mode" hidden>
            <label for="switch-mode" class="switch-mode"></label>
            <a href="#" class="profile">
                <img src="img/admin.jpg">
            </a>
        </nav>
        <main>
            <div class="head-title">
                <div class="left">
                    <h1>Movies</h1>
                    <ul class="breadcrumb">
                        <li>
                            <a href="movies.php">Dashboard</a>
                        </li>
                        <li><i class='bx bx-chevron-right'></i></li>
                        <li>
                            <a class="active" href="movies.php">Movies</a>
                        </li>
                    </ul>
                </div>
            </div>
            <div class="form-container">
                <h1>Edit Movie</h1>
                <form action="edit_movie.php?id=<?= htmlspecialchars($movie_id) ?>" method="POST">
                    <div class="form-group">
                        <label for="title">Movie Title</label>
                        <input type="text" name="title" id="title" value="<?= htmlspecialchars($movie['title']) ?>" required>
                    </div>
                    <div class="form-group">
                        <label for="description">Description</label>
                        <textarea name="description" id="description" rows="4" required><?= htmlspecialchars($movie['description']) ?></textarea>
                    </div>
                    <div class="form-group">
                        <label for="release_year">Release Year</label>
                        <input type="number" name="release_year" id="release_year" min="1900" max="<?= date('Y') ?>" value="<?= htmlspecialchars($movie['release_year']) ?>" required>
                    </div>
                    <div class="form-group">
                        <label for="rating">Rating</label>
                        <input type="number" name="rating" id="rating" step="0.1" min="0" max="10" value="<?= htmlspecialchars($movie['rating']) ?>" required>
                    </div>
                    <div class="form-group">
                        <label for="trailer">Trailer</label>
                        <input type="file" name="trailer" id="trailer" accept="video/*" required>
                    </div>
                    <div class="form-group">
                        <label for="poster">Poster</label>
                        <input type="file" name="poster" id="poster" accept="image/*" required>
                        <img id="poster-preview" src="../assets/images/posters/<?= htmlspecialchars($movie['poster']) ?>" alt="Poster Preview" style="max-width: 200px; display: block;">
                    </div>
                    <div class="form-group">
                        <label for="duration">Duration (in minutes)</label>
                        <input type="number" name="duration" id="duration" value="<?= htmlspecialchars($movie['duration']) ?>" required>
                    </div>
                    <div class="form-group">
                        <label for="genres">Genres</label>
                        <div id="genres" class="genre-grid">
                            <?php foreach ($genres as $genre): ?>
                                <div class="genre-item">
                                    <input type="checkbox" name="genres[]" id="genre_<?= htmlspecialchars($genre['genre_id']) ?>" value="<?= htmlspecialchars($genre['genre_id']) ?>"
                                        <?= in_array($genre['genre_id'], $selected_genres) ? 'checked' : '' ?>>
                                    <label for="genre_<?= htmlspecialchars($genre['genre_id']) ?>"><?= htmlspecialchars($genre['genre_name']) ?></label>
                                </div>
                            <?php endforeach; ?>
                        </div>
                    </div>
                    <button type="submit" class="submit-btn">Update Movie</button>
                    <?php if (isset($error)): ?>
                        <p class="error"><?= htmlspecialchars($error) ?></p>
                    <?php endif; ?>
                </form>
            </div>
        </main>
    </section>

    <script>
        // Preview poster when selected
        const posterInput = document.getElementById('poster');
        const posterPreview = document.getElementById('poster-preview');
        posterInput.addEventListener('change', () => {
            const file = posterInput.files[0];
            if (file) {
                posterPreview.src = URL.createObjectURL(file);
                posterPreview.style.display = 'block';
            }
        });
    </script>
	<script src="script.js"></script>
</body>
</html>