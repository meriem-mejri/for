<?php
// Include database connection
include '../connection/connect.php';

// Check if the rental ID is set in the URL
if (isset($_GET['id']) && !empty($_GET['id'])) {
    $rental_id = $_GET['id'];

    // Prepare a DELETE statement to remove the rental
    $delete_query = "DELETE FROM rentals WHERE rental_id = ?";

    if ($stmt = $conn->prepare($delete_query)) {
        // Bind the rental_id parameter
        $stmt->bind_param("i", $rental_id);

        // Execute the statement
        if ($stmt->execute()) {
            // Redirect to the rentals page with a success message
            header("Location: rentals.php?message=Rental deleted successfully");
        } else {
            // Redirect to the rentals page with an error message
            header("Location: rentals.php?message=Error deleting rental");
        }

        // Close the statement
        $stmt->close();
    } else {
        // Redirect to the rentals page with an error message if the statement fails
        header("Location: rentals.php?message=Error preparing query");
    }

    // Close the database connection
    $conn->close();
} else {
    // Redirect to the rentals page if no rental ID is provided
    header("Location: rentals.php?message=Invalid rental ID");
}
?>