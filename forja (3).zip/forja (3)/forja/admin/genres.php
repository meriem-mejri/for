<?php
// Database connection
include '../connection/connect.php';
$result = $conn->query("SELECT * FROM genres");
$genres = $result->fetch_all(MYSQLI_ASSOC);

// Close the database connection
$conn->close();

?>

<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">

        <!-- Boxicons -->
        <link href='https://unpkg.com/boxicons@2.0.9/css/boxicons.min.css' rel='stylesheet'>
        <script src="https://kit.fontawesome.com/48967be5bb.js" crossorigin="anonymous"></script>
        <!-- My CSS -->
        <link rel="stylesheet" href="style.css">
        <link rel="shortcut icon" href="../assets/images/favicon.svg" type="image/svg+xml">
        <title>Genres</title>
        <style>
            .genres-container {
                margin-top: 30px;
                width: 99.99%;
                background: #F9F9F9;
                border-radius: 10px;
                box-shadow: 0 4px 10px rgba(0, 0, 0, 0.1);
                padding: 20px;
            }
            .genres-container.dark {
                background-color: #0c0c1e;
                box-shadow: 0 4px 10px hsl(207, 19%, 11%);
            }
            .genres-header {
                text-align: center;
                margin-bottom: 20px;
            }
            .genres-header h1 {
                margin: 0;
                font-size: 24px;
                color: #333;
            }
            .genres-list {
                list-style: none;
                padding: 0;
                margin: 0;
            }
            .genres-list li {
                display: flex;
                justify-content: space-between;
                align-items: center;
                background: #fafafa;
                border: 1px solid #e0e0e0;
                border-radius: 8px;
                margin-bottom: 10px;
                padding: 15px 20px;
                transition: transform 0.2s, background 0.3s;
            }
            .genres-list li:hover {
                background: #eee;
                transform: translateY(-2px);
            }
            .genre-info {
                max-width: 70%;
            }
            .genre-info h2 {
                margin: 0;
                font-size: 18px;
                color: #555;
            }
            .genre-info p {
                margin: 5px ;
                width:800px;
                font-size: 14px;
                color: #777;
            }
            .genre-actions {
                display: flex;
                gap: 10px;
            }
            .genre-actions a {
                display: flex;
                align-items: center;
                justify-content: center;
                width: 40px;
                height: 40px;
                background: #e0e0e0;
                border-radius: 50%;
                text-decoration: none;
                color: #555;
                font-size: 18px;
                transition: background 0.3s, color 0.3s;
            }
            .genre-actions a:hover {
                background: #eee;
                color: #fff;
            }

            body.dark .genres-header h1, body.dark h2 {
                color: #fff; 
            }

            body.dark .genres-list li {
                background: hsl(229, 15%, 21%); /* Dark background for list items */
                border: 1px solid #060714; /* Darker border */
            }

            body.dark .genres-list li:hover {
                background: #0C0C1E; /* Slightly lighter dark background on hover */
            }

            body.dark .genre-info h2 {
                color: #ddd; /* Lighter text for genre name */
            }

            body.dark .genre-info p {
                color: #bbb; /* Lighter text for genre description */
            }

            body.dark .genre-actions a {
                background: hsl(229, 15%, 21%);  /* Dark background for action buttons */
                color: #fff; /* White color for icons */
            }

            body.dark .genre-actions a:hover {
                background: #06071e; /* Lighter background on hover */
                color: #fff; /* Ensure text/icon stays white on hover */
            }
        </style>
    </head>
    <body>
        <!-- SIDEBAR -->
        <section id="sidebar">
            <a href="#" class="brand">
            <img src="../assets/images/favicon.svg"  type="image/svg+xml" >
                <span class="text">Forja</span>
            </a>
            <ul class="side-menu top">
                <li >
                    <a href="index.php">
                        <i class='bx bxs-dashboard' ></i>
                        <span class="text">Dashboard</span>
                    </a>
                </li>
                <li class="active">
                    <a href="genres.php">
                    <i class='bx bxs-category'></i>
                        <span class="text">Genres</span>
                    </a>
                </li>
                <li>
                    <a href="movies.php">
                    <i class='bx bx-movie'></i>
                        <span class="text">Movies</span>
                    </a>
                </li>
                <li>
                    <a href="users.php">
                    <i class='bx bxs-group'></i>
                        <span class="text">Users</span>
                    </a>
                </li>
                <li>
                    <a href="rentals.php">
                    <i class='bx bx-store-alt'></i>
                        <span class="text">Rentals</span>
                    </a>
                </li>
                
            </ul>
            <ul class="side-menu">
                
                <li>
                    <a href="logout.php" class="logout">
                        <i class='bx bxs-log-out-circle' ></i>
                        <span class="text">Logout</span>
                    </a>
                </li>
            </ul>
        </section>

        <!-- CONTENT -->
        <section id="content">
            <!-- NAVBAR -->
            <nav>
                <i class='bx bx-menu' ></i>
                <form action="#">
                    <div class="form-input">
                        <input type="search" placeholder="Search...">
                        <button type="submit" class="search-btn"><i class='bx bx-search' ></i></button>
                    </div>
                </form>
                <input type="checkbox" id="switch-mode" hidden>
                <label for="switch-mode" class="switch-mode"></label>
                
                <a href="#" class="profile">
                <img src="img/admin.jpg">
                </a>
            </nav>

            <!-- MAIN -->
            <main>
                <div class="head-title">
                    <div class="left">
                        <h1>Genres</h1>
                        <ul class="breadcrumb">
                            <li>
                                <a href="genres.php">Dashboard</a>
                            </li>
                            <li><i class='bx bx-chevron-right' ></i></li>
                            <li>
                                <a class="active" href="genres.php">Genres</a>
                            </li>
                        </ul>
                    </div>
                </div>
                <div class="genres-container">
                    <div class="genres-header">
                        <h1>Genres List</h1> 
                    </div>

                    <ul class="genres-list">
                        <?php foreach ($genres as $genre): ?>
                        <li>
                            <div class="genre-info">
                                <h2><?php echo htmlspecialchars($genre['genre_name']); ?></h2>
                                <p><?php echo htmlspecialchars($genre['description']); ?></p>
                            </div>
                            <div class="genre-actions">
                                <!-- Edit icon -->
                                <a href="edit_genre.php?id=<?php echo $genre['genre_id']; ?>" title="Edit Genre">✏️</a>
                                
                                <a href="delete_genre.php?id=<?php echo $genre['genre_id']; ?>" 
                                onclick="return confirmDeletion('<?php echo $genre['genre_name']; ?>', <?php echo $genre['genre_id']; ?>)"
                                title="Delete Genre"> ❌
                                </a>

                                <script>
                                    function confirmDeletion(genreName, genreId) {
                                        // Show a confirmation dialog
                                        var result = confirm('Are you sure you want to delete the genre: ' + genreName + '?');
                                        
                                        // If the user clicked "OK" (result is true), then proceed with the deletion by navigating to delete.php
                                        if (result) {
                                            window.location.href = 'delete_genre.php?id=' + genreId;
                                        } else {
                                            return false; // Prevent the link from being followed if the user clicks "Cancel"
                                        }
                                    }
                                </script>
                            </div>
                        </li>
                        <?php endforeach; ?>
                    </ul>
                    <h2 style="text-align:center">Add Genre <a href="add_genre.php" title="Add Genre">➕</a></h2>
                </div>
            </main>
        </section>
        <script src="script.js"></script>
    </body>
</html>