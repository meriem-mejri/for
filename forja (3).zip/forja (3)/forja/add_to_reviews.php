<?php
// Include the connection file
include 'connection/connect.php';
session_start();

if (!isset($_SESSION['username'])) {
    echo "
    <html lang='en'>
    <head>
        <style>
            body {
                background-color: hsl(228, 13%, 15%);
                margin: 0;
                padding: 0;
                display: flex;
                justify-content: center;
                align-items: center;
                height: 100vh;
                font-family: Arial, sans-serif;
            }

            .error-container {
                background-color: hsl(216, 22%, 18%);
                border-radius: 8px;
                box-shadow: 0 4px 8px hsl(216, 22%, 18%);
                padding: 20px;
                width: 600px;
                text-align: center;
                color: red;
            }

            .error-container h1 {
                font-size: 24px;
                color: white;
                margin-bottom: 20px;
            }

            .error-container p {
                font-size: 18px;
                font-weight: bold;
                margin: 20px 0;
            }

            .error-container a {
                display: inline-block;
                background-color: hsl(57, 97%, 45%);
                color: white;
                text-decoration: none;
                padding: 10px 20px;
                font-size: 18px;
                border-radius: 5px;
                font-family: Arial, sans-serif;
                cursor: pointer;
            }

            .error-container a:hover {
                background-color: hsl(0, 7%, 88%);
                color: black;
                transition: 1s ease;
            }
        </style>
    </head>
    <body>
        <div class='error-container'>
            <h1>Error</h1>
            <p>You must be logged in to add a movie to your wishlist!</p>
            <a href='login.php'>Login</a>
        </div>
    </body>
    </html>
    ";
    exit;
}

// Get the username from the session
$username = $_SESSION['username'];

// Fetch the user_id from the database based on the username
$stmt = $conn->prepare('SELECT user_id FROM users WHERE username = ? LIMIT 1');
$stmt->bind_param('s', $username);
$stmt->execute();
$stmt->store_result();

// If the username is found, fetch the user_id
if ($stmt->num_rows > 0) {
    $stmt->bind_result($user_id);
    $stmt->fetch();
} else {
    die('User not found.');
}
$stmt->close();

// Get the movie_id from the GET parameter
$movie_id = isset($_GET['movie_id']) ? intval($_GET['movie_id']) : 0;
$rating = isset($_POST['rating']) ? (float) $_POST['rating'] : null;
$review_text = isset($_POST['review']) ? $_POST['review'] : null;

// Validate movie_id
$stmt = $conn->prepare('SELECT 1 FROM movies WHERE movie_id = ?');
$stmt->bind_param('i', $movie_id);
$stmt->execute();
$stmt->store_result();
if ($stmt->num_rows === 0) {
    die('Invalid movie ID.');
}
$stmt->close();

// Check if the movie is already in the reviews
$stmt = $conn->prepare('SELECT * FROM reviews WHERE user_id = ? AND movie_id = ?');
$stmt->bind_param('ii', $user_id, $movie_id);
$stmt->execute();
$result = $stmt->get_result();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Movie Wishlist</title>
    <style>
        body {
            font-family: 'Arial', sans-serif;
            background-color: hsl(228, 13%, 15%);
            margin: 0;
            padding: 0;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
        }

        .container {
            background-color: hsl(216, 22%, 18%);
            border-radius: 8px;
            box-shadow: 0 4px 8px hsl(216, 22%, 18%);
            padding: 20px;
            width: 600px;
            text-align: center;
        }

        h1 {
            color: #333;
            font-size: 24px;
        }

        .message {
            font-size: 18px;
            color: #555;
            margin: 20px 0;
        }

        .success {
            color: #4CAF50;
            font-weight: bold;
        }

        .error {
            color: hsl(57, 97%, 45%);
            font-weight: bold;
        }

        .button {
            background-color: hsl(57, 97%, 45%);
            color: white;
            border: none;
            padding: 10px 20px;
            font-size: 18px;
            border-radius: 5px;
            cursor: pointer;
            text-decoration: none;
            display: inline-block;
            margin-top: 20px;
        }

        .button:hover {
            background-color: hsl(0, 7%, 88%);
            color: black;
            transition: 1s ease;
        }
    </style>
</head>
<body>

<div class="container">
    <?php if ($result->num_rows > 0): ?>
        <p class="message error">You have already reviewed this film.</p>
    <?php else: ?>
        <?php
        // Ensure rating and review are set before inserting
        if ($rating === null || $review_text === null) {
            echo '<p class="message error">Rating and review are required.</p>';
        } else {
            // Insert the review into the database
            $stmt = $conn->prepare('INSERT INTO reviews (user_id, movie_id, rating, review_text) VALUES (?, ?, ?, ?)');
            $stmt->bind_param('iiis', $user_id, $movie_id, $rating, $review_text);

            if ($stmt->execute()) {
                echo '<p class="message success">You have reviewed this movie successfully!</p>';
            } else {
                echo '<p class="message error">Failed to add the movie to the reviews. Error: ' . $stmt->error . '</p>';
            }

            $stmt->close();
        }
        ?>
    <?php endif; ?>
    <a href="movie-details.php?movie_id=<?php echo $movie_id; ?>" class="button">Go Back</a>
</div>

</body>
</html>
