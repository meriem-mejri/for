<?php 
include 'connection/connect.php';
session_start();

// Fetch genres from the database
$query = "SELECT genre_name, description FROM genres";
$result = $conn->query($query);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="shortcut icon" href="./assets/images/favicon.svg" type="image/svg+xml">
    <title>Movie Genres</title>
    <link rel="stylesheet" href="./assets/css/genress.css">
</head>
<body>

<div class="container">
    <h1>Select 3 Movie Genres</h1>

    <form id="genres-form" method="POST" action="genres.php">
        <div class="genre-grid">
            <?php 
            // Check if the query returned any results
            if ($result->num_rows > 0) {
                // Loop through each genre and create a checkbox dynamically
                while ($row = $result->fetch_assoc()) {
                    $genre_name = htmlspecialchars($row['genre_name']);
                    $description = htmlspecialchars($row['description']);
            ?>
                <div class="genre-card">
                    <input type="checkbox" id="<?php echo $genre_name; ?>" name="genre[]" value="<?php echo $genre_name; ?>">
                    <label for="<?php echo $genre_name; ?>" class="genre-label">
                        <div class="genre-content">
                            <h3><?php echo $genre_name; ?></h3>
                            <p><?php echo $description; ?></p>
                        </div>
                    </label>
                </div>
            <?php 
                }
            }
            ?>
        </div>
        <button class="bot" type="submit">Submit</button>
    </form>

    <p id="error-message" style="color: red; display: none;">Please select exactly 3 genres.</p>
</div>

<script>
// Script to validate the form and ensure exactly 3 genres are selected
document.getElementById("genres-form").addEventListener("submit", function(event) {
    var selectedGenres = document.querySelectorAll('input[name="genre[]"]:checked');
    if (selectedGenres.length !== 3) {
        event.preventDefault();
        document.getElementById("error-message").style.display = "block";
    } else {
        document.getElementById("error-message").style.display = "none";
    }
});
</script>

<?php
// Process the form submission
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    if (isset($_POST['genre']) && count($_POST['genre']) == 3) {
        $_SESSION['selected_genres'] = $_POST['genre']; // Save the genres in session
        // Redirect to login.php or any other page to show movies based on selected genres
        echo "<script>window.location.href='login.php';</script>";
    } else {
        echo "<script>document.getElementById('error-message').style.display = 'block';</script>";
    }
}
?>

</body>
</html>