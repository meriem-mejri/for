<?php
  include 'connection/connect.php';
  session_start();
  if (isset($_SESSION['username'])) {
    // If the user is logged in, display a personalized greeting
    $username = $_SESSION['username'];
    // Fetch the user_id from the database based on the username
  $stmt = $conn->prepare('SELECT user_id FROM users WHERE username = ? LIMIT 1');
  $stmt->bind_param('s', $username);
  $stmt->execute();
  $stmt->store_result();

  // If the username is found, fetch the user_id
  if ($stmt->num_rows > 0) {
      $stmt->bind_result($user_id);
      $stmt->fetch();
  } else {
      die('User not found.');
  }
  $stmt->close();// Debugging line to check user_id
  } else {
    // If not logged in, set a default username or message
    $username = "Guest";
  }

  // Fetch genres from the database
  $genreStmt = $conn->prepare('SELECT genre_id, genre_name FROM genres');
  $genreStmt->execute();
  $genreResult = $genreStmt->get_result();

  $genreStmt->close();
?>

<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://cdn.jsdelivr.net/npm/remixicon@3.5.0/fonts/remixicon.css" rel="stylesheet"/>
    <title>FORJA - Best movie collections</title>
    <!-- favicon -->
    <link rel="shortcut icon" href="./assets/images/favicon.svg" type="image/svg+xml">
    <!-- custom css link -->
    <link rel="stylesheet" href="./assets/css/style.css">
    <!-- google font link -->
    <script src="https://kit.fontawesome.com/48967be5bb.js" crossorigin="anonymous"></script>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;500;600;700&display=swap" rel="stylesheet">
  </head>

  <body id="top">
    <!-- #HEADER -->
    <header class="header" data-header>
      <div class="container">
        <div class="overlay" data-overlay></div>

        <a href="./index.php" class="logo">
          <img src="./assets/images/forjalogo.png" alt="Filmlane logo" width="150" height="50">
        </a>

        <div class="header-actions">
          <?php if (isset($_SESSION['username'])): ?>
            <button class="btn btn-primary" onclick="window.location.href='logout.php'">Sign Out</button>
          <?php else: ?>
            <button class="btn btn-primary" onclick="window.location.href='login.php'">Sign In</button>
          <?php endif; ?>
        </div>

        <button class="menu-open-btn" data-menu-open-btn>
          <ion-icon name="reorder-two"></ion-icon>
        </button>

        <nav class="navbar" data-navbar>
          <div class="navbar-top">
            <a href="./index.php" class="logo">
              <img src="./assets/images/forja.png" alt="Forja logo">
            </a>
            <button class="menu-close-btn" data-menu-close-btn>
              <ion-icon name="close-outline"></ion-icon>
            </button>
          </div>
          <ul class="navbar-list">
            <li>
              <a href="./index.php" class="navbar-link">Home</a>
            </li>
            <li>
              <a href="javascript:void(0);" class="navbar-link" data-target=".upcoming">Movies</a>
              <script>
                document.querySelectorAll('.navbar-link').forEach(anchor => {
                  anchor.addEventListener('click', function (e) {
                    e.preventDefault();
                    const target = document.querySelector(this.getAttribute('data-target'));
                    if (target) {
                      target.scrollIntoView({ behavior: 'smooth' });
                    }
                  });
                });
              </script>
            </li>
            <li>
              <a href="javascript:void(0);" class="navbar-link" data-target=".genres">Genres</a>
              <script>
                document.querySelectorAll('.navbar-link').forEach(anchor => {
                    anchor.addEventListener('click', function (e) {
                        e.preventDefault();
                        const target = document.querySelector(this.getAttribute('data-target'));
                        if (target) {
                            target.scrollIntoView({ behavior: 'smooth' });
                        }
                    });
                });
              </script>
            </li>
            <li>
              <?php if (isset($_SESSION['username'])): ?>
                <a href="rentals.php?user_id=<?php echo $user_id; ?>" class="wishlist">Rentals</a>
              <?php endif; ?>
            </li>
            <li>
              <?php if (isset($_SESSION['username'])): ?>
                <a href="wishlist.php?user_id=<?php echo $user_id; ?>" class="wishlist">Wishlist</a>
              <?php endif; ?>
            </li>
          </ul>
        </nav>
      </div>
    </header>
    <main>
      <article>
        <!-- #HERO -->
        <section class="hero">
          <div class="container">
            <div class="hero-content"> 
              <?php if (isset($_SESSION['username'])): ?>
                <p class="user">Welcome <?= htmlspecialchars($_SESSION['username']); ?> !</p><br><br>
              <?php endif; ?>
              <h1 class="h1 hero-title">
                Unlimited <strong>Movies</strong><br>Your <strong>Favorite</strong> Films Anytime.
              </h1>
            </div>
          </div>
        </section>
        <!-- #movies -->
        <section class="upcoming">
          <div class="container">
            <div class="flex-wrapper">
              <div class="title-wrapper">
                <h2 class="h2 section-title">Our Movies</h2>
              </div>
            </div>
            <ul class="movies-list has-scrollbar">
          <?php
          if (isset($_SESSION['username'])) {
              // Get selected genres from session (genre names)
$selected_genres = $_SESSION['selected_genres'] ?? [];

// Query to get genre IDs for selected genres
$genre_condition = !empty($selected_genres) ? "AND g.genre_name IN ('" . implode("', '", $selected_genres) . "')" : "";

$query_filtered = "
    SELECT DISTINCT m.movie_id, m.title, m.release_year, m.rating, m.duration, m.poster
    FROM movies m
    JOIN movie_genres mg ON m.movie_id = mg.movie_id
    JOIN genres g ON mg.genre_id = g.genre_id
    WHERE 1=1 $genre_condition
    ORDER BY FIELD(g.genre_name, '" . implode("', '", $selected_genres) . "') DESC, m.release_year DESC
";
$result_filtered = $conn->query($query_filtered);

// Query for remaining films not associated with selected genres
$query_remaining_films = "
    SELECT DISTINCT m.movie_id, m.title, m.release_year, m.rating, m.duration, m.poster
    FROM movies m
    WHERE m.movie_id NOT IN (
        SELECT DISTINCT mg.movie_id 
        FROM movie_genres mg
        JOIN genres g ON mg.genre_id = g.genre_id
        WHERE g.genre_name IN ('" . implode("', '", $selected_genres) . "')
    )
    ORDER BY m.release_year DESC
";
$result_remaining_films = $conn->query($query_remaining_films);


          } else {
              $query = "SELECT m.movie_id, m.title, m.release_year, m.rating, m.duration, m.poster
                        FROM movies m
                        ORDER BY m.movie_id ASC";
              $result = $conn->query($query);
          }

          $counter = 0;

          if (isset($_SESSION['username'])) {
              while ($movie = $result_filtered->fetch_assoc()) {
                  if ($counter % 4 == 0 && $counter != 0) {
                      echo '</ul><ul class="movies-list has-scrollbar">';
                  }
          ?>
              <li>
                  <div class="movie-card">
                      <a href="./movie-details.php?movie_id=<?php echo $movie['movie_id']; ?>">
                          <figure class="card-banner">
                              <img src="./assets/images/posters/poster<?php echo $movie['movie_id']; ?>.jpg" alt="<?php echo htmlspecialchars($movie['title']); ?> movie poster">
                          </figure>
                      </a>

                      <div class="title-wrapper">
                          <a href="./movie-details.php?movie_id=<?php echo $movie['movie_id']; ?>">
                              <h3 class="card-title"><?php echo htmlspecialchars($movie['title']); ?></h3>
                          </a>
                          <time datetime="<?php echo $movie['release_year']; ?>"><?php echo $movie['release_year']; ?></time>
                      </div>

                      <div class="card-meta">
                          <div class="badge badge-outline"><?php echo $movie['rating'] >= 8 ? 'HD' : '4K'; ?></div>
                          <div class="duration">
                              <ion-icon name="time-outline"></ion-icon>
                              <time datetime="PT<?php echo $movie['duration']; ?>M"><?php echo $movie['duration']; ?> min</time>
                          </div>
                          <div class="rating">
                              <ion-icon name="star"></ion-icon>
                              <data><?php echo $movie['rating']; ?></data>
                          </div>
                      </div>
                  </div>
              </li>
          <?php 
                  $counter++; 
              }

              while ($movie = $result_remaining_films->fetch_assoc()) {
                  if ($counter % 4 == 0 && $counter != 0) {
                      echo '</ul><ul class="movies-list has-scrollbar">';
                  }
          ?>
                <li>
                    <div class="movie-card">
                        <a href="./movie-details.php?movie_id=<?php echo $movie['movie_id']; ?>">
                          <figure class="card-banner">
                              <img src="./assets/images/posters/poster<?php echo $movie['movie_id']; ?>.jpg" alt="<?php echo htmlspecialchars($movie['title']); ?> movie poster">
                          </figure>
                        </a>

                        <div class="title-wrapper">
                            <a href="./movie-details.php?movie_id=<?php echo $movie['movie_id']; ?>">
                                <h3 class="card-title"><?php echo htmlspecialchars($movie['title']); ?></h3>
                            </a>
                            <time datetime="<?php echo $movie['release_year']; ?>"><?php echo $movie['release_year']; ?></time>
                        </div>

                        <div class="card-meta">
                            <div class="badge badge-outline"><?php echo $movie['rating'] >= 8 ? 'HD' : '4K'; ?></div>
                            <div class="duration">
                                <ion-icon name="time-outline"></ion-icon>
                                <time datetime="PT<?php echo $movie['duration']; ?>M"><?php echo $movie['duration']; ?> min</time>
                            </div>
                            <div class="rating">
                                <ion-icon name="star"></ion-icon>
                                <data><?php echo $movie['rating']; ?></data>
                            </div>
                        </div>
                    </div>
                </li>
            <?php 
                    $counter++; 
                }
            } else {
                while ($movie = $result->fetch_assoc()) {
                    if ($counter % 4 == 0 && $counter != 0) {
                        echo '</ul><ul class="movies-list has-scrollbar">';
                    }
            ?>
              <li>
                  <div class="movie-card">
                      <a href="./movie-details.php?movie_id=<?php echo $movie['movie_id']; ?>">
                          <figure class="card-banner">
                              <img src="./assets/images/posters/poster<?php echo $movie['movie_id']; ?>.jpg" alt="<?php echo htmlspecialchars($movie['title']); ?> movie poster">
                          </figure>
                      </a>

                      <div class="title-wrapper">
                          <a href="./movie-details.php?movie_id=<?php echo $movie['movie_id']; ?>">
                              <h3 class="card-title"><?php echo htmlspecialchars($movie['title']); ?></h3>
                          </a>
                          <time datetime="<?php echo $movie['release_year']; ?>"><?php echo $movie['release_year']; ?></time>
                      </div>

                      <div class="card-meta">
                          <div class="badge badge-outline"><?php echo $movie['rating'] >= 8 ? 'HD' : '4K'; ?></div>
                          <div class="duration">
                              <ion-icon name="time-outline"></ion-icon>
                              <time datetime="PT<?php echo $movie['duration']; ?>M"><?php echo $movie['duration']; ?> min</time>
                          </div>
                          <div class="rating">
                              <ion-icon name="star"></ion-icon>
                              <data><?php echo $movie['rating']; ?></data>
                          </div>
                      </div>
                  </div>
              </li>
              <?php 
                      $counter++; 
                  }
              }
              ?>
          </ul>
          </div>
        </section>
        <!-- #SERVICE -->
        <section class="service">
          <div class="container">
            <div class="service-banner">
              <figure>
                <img src="./assets/images/4k1.png" alt="HD 4k resolution! only 3 DT" width="900" height="400">
              </figure>
            </div>

            <div class="service-content">

              <p class="service-subtitle">Our Services</p>

              <h2 class="h2 service-title">Rent Your Favorite Movies and Watch Anytime.</h2>

              <p class="service-text">
                Choose from a vast collection of movies to rent and enjoy them on your own schedule.
                Watch your rented films wherever and whenever you want.
              </p>

              <ul class="service-list">

                <li>
                  <div class="service-card">

                    <div class="card-icon">
                      <ion-icon name="tv"></ion-icon>
                    </div>

                    <div class="card-content">
                      <h3 class="h3 card-title">Enjoy on Your TV.</h3>

                      <p class="card-text">
                        Stream your rented movies directly on your TV for the ultimate cinematic experience at home.
                      </p>
                    </div>

                  </div>
                </li>

                <li>
                  <div class="service-card">

                    <div class="card-icon">
                      <ion-icon name="videocam"></ion-icon>
                    </div>

                    <div class="card-content">
                      <h3 class="h3 card-title">Rent Anywhere, Watch Everywhere.</h3>

                      <p class="card-text">
                        Browse and rent movies easily from any device. Start watching on your phone, tablet, or TV – no limits!
                      </p>
                    </div>

                  </div>
                </li>

              </ul>

            </div>

          </div>
        </section>
        <!-- #TOP RATED -->
        <section class="upcoming">
          <div class="container">
            <div class="flex-wrapper">
              <div class="title-wrapper">
                <h2 class="h2 section-title">Top Rated Movies</h2>
              </div>
            </div>
            <ul class="movies-list has-scrollbar">
              <?php
              // Connexion à la base de données et récupération des films
              $query = "SELECT m.movie_id, m.title, m.release_year, m.rating, m.duration, m.poster
                        FROM movies m 
                        ORDER BY m.rating DESC
                        LIMIT 10"; // Vous pouvez ajouter des conditions si nécessaire
              $result = $conn->query($query);

              // Compteur pour regrouper les films par 4
              $counter = 0;

              // Affichage des films
              while ($movie = $result->fetch_assoc()) {
                  // Ouvrir une nouvelle ligne après chaque 4 films
                  if ($counter % 10 == 0 && $counter != 0) {
                      echo '</ul><ul class="movies-list has-scrollbar">';
                  }
              ?>
                  <li>
                      <div class="movie-card">
                          <a href="./movie-details.php?movie_id=<?php echo $movie['movie_id']; ?>">
                              <figure class="card-banner">
                                  <img src="./assets/images/posters/poster<?php echo $movie['movie_id']; ?>.jpg" alt="<?php echo htmlspecialchars($movie['title']); ?> movie poster">
                              </figure>
                          </a>

                          <div class="title-wrapper">
                              <a href="./movie-details.php?movie_id=<?php echo $movie['movie_id']; ?>">
                                  <h3 class="card-title"><?php echo htmlspecialchars($movie['title']); ?></h3>
                              </a>
                              <time datetime="<?php echo $movie['release_year']; ?>"><?php echo $movie['release_year']; ?></time>
                          </div>

                          <div class="card-meta">
                              <div class="badge badge-outline"><?php echo $movie['rating'] >= 8 ? 'HD' : '4K'; ?></div>

                              <div class="duration">
                                  <ion-icon name="time-outline"></ion-icon>
                                  <time datetime="PT<?php echo $movie['duration']; ?>M"><?php echo $movie['duration']; ?> min</time>
                              </div>

                              <div class="rating">
                                  <ion-icon name="star"></ion-icon>
                                  <data><?php echo $movie['rating']; ?></data>
                              </div>
                          </div>
                      </div>
                  </li>
              <?php 
                $counter++;
              } 
              ?>
            </ul>
          </div>
        </section>
        <!-- movies by genre -->
        <section class="genres">
          <div class="container">
            <div class="flex-wrapper">
              <div class="title-wrapper"><br>
                <h2 class="h2 section-title">Movies by Genre</h2>
              </div>
            </div>
            <div>
              <ul class="filter-list">
                <?php while ($genre = $genreResult->fetch_assoc()): ?>
                  <li>
                    <!-- Add an anchor that will load movies by genre dynamically -->
                    <a href="javascript:void(0);" onclick="loadMoviesByGenre(<?= $genre['genre_id'] ?>)" class="filter-btn">
                      <?= htmlspecialchars($genre['genre_name']) ?>
                    </a>
                  </li>
                <?php endwhile; ?>
              </ul>
            </div>

            <div id="movies-list-container">
              <!-- This is where the movie list will be dynamically inserted -->
              <?php if (!empty($movies)): ?>
              <ul class="movies-list has-scrollbar mt-4">
                <?php 
                $counter = 0;
                foreach ($movies as $movie): 
                  if ($counter % 10 == 0 && $counter != 0) {
                      echo '</ul><ul class="movies-list has-scrollbar mt-4">';
                  }
                ?>
                  <li>
                    <div class="movie-card">
                      <a href="./movie-details.php?movie_id=<?= $movie['movie_id'] ?>">
                        <figure class="card-banner">
                          <img src="./assets/images/posters/poster<?= $movie['movie_id'] ?>.jpg" alt="<?= htmlspecialchars($movie['title']) ?> movie poster">
                        </figure>
                      </a>
                      <div class="title-wrapper">
                        <a href="./movie-details.php?movie_id=<?= $movie['movie_id'] ?>">
                          <h3 class="card-title"><?= htmlspecialchars($movie['title']) ?></h3>
                        </a>
                        <time datetime="<?= $movie['release_year'] ?>"><?= $movie['release_year'] ?></time>
                      </div>
                      <div class="card-meta">
                        <div class="badge badge-outline">
                          <?= $movie['rating'] >= 8 ? 'HD' : '4K' ?>
                        </div>
                        <div class="duration">
                          <ion-icon name="time-outline"></ion-icon>
                          <time datetime="PT<?= $movie['duration'] ?>M"><?= $movie['duration'] ?> min</time>
                        </div>
                        <div class="rating">
                          <ion-icon name="star"></ion-icon>
                          <data><?= $movie['rating'] ?></data>
                        </div>
                      </div>
                    </div>
                  </li>
                <?php 
                  $counter++;
                endforeach; 
                ?>
              </ul>
              <?php endif; ?>
            </div>
          </div>
        </section>

        <script>
          function loadMoviesByGenre(genreId) {
            // Use AJAX to fetch the filtered movie list based on the selected genre
            var xhr = new XMLHttpRequest();
            xhr.open('GET', 'fetch_movies_by_genre.php?genre_id=' + genreId, true);
            xhr.onload = function() {
              if (xhr.status === 200) {
                document.getElementById('movies-list-container').innerHTML = xhr.responseText;
              }
            };
            xhr.send();
          }
        </script>

        <!-- #Testimonials -->
        <section class="section__container">
          <h2>Testimonials</h2>
          <h1>What our customers say</h1>
          <div class="section__grid">
            <div class="section__card">
              <span><i class="ri-double-quotes-l"></i></span>
              <h4>Love the simplicity</h4>
              <p>
                Sleek, intuitive, and perfectly designed for an exceptional film rental experience.
                The user-friendly interface makes browsing and renting movies a breeze. Very impressed!</p>
              <img src="assets/images/user-1.jpg" alt="user" />
              <h5>Allan Collins</h5>
              <h6>Sound designer</h6>
            </div>
            <div class="section__card">
              <span><i class="ri-double-quotes-l"></i></span>
              <h4>Excellent Designs</h4>
              <p>
                Impressive visuals and user-friendly design. 
                Perfect for enhancing our film rental platform. <br>Strongly endorsed!
              </p>
              <img src="assets/images/user-2.jpg" alt="user" />
              <h5>Tanya Grant</h5>
              <h6>Film Editor</h6>
            </div>
            <div class="section__card">
              <span><i class="ri-double-quotes-l"></i></span>
              <h4>Efficient and Reliable</h4>
              <p>
                The platform is perfect for film rentals, with a stunning design and exceptional support.
                A hassle-free experience from start to finish!"
              </p>
              <img src="assets/images/user-3.jpg" alt="user" />
              <h5>Clay Washington</h5>
              <h6>Film Enthusiast</h6>
            </div>
          </div>
        </section>
        <!-- #CTA -->
        <section class="cta">
          <div class="container">
            <div class="title-wrapper">
              <h2 class="cta-title">Subscribe Now!<br>
                Get the latest updates and <br>deals to your inbox!
              </h2>
              <p class="cta-text">
                Enter your email to subscribe to our newsletter
              </p>
            </div>
            <form action="" class="cta-form">
              <input type="email" name="email" required placeholder="Enter your email" class="email-field">
              <button type="submit" class="cta-form-btn">Get started</button>
            </form>
          </div>
        </section>
      </article>
    </main>
    <!-- #FOOTER -->
    <footer class="footer">
      <div class="footer-top">
        <div class="container">
          <div class="footer-brand-wrapper">
            <a href="./index.html" class="logo">
              <img src="./assets/images/forjalogo.png" alt="Filmlane logo" height="50" width="150">
            </a>
            <ul class="footer-list">
              <li><a href="./index.php" class="footer-link">Home</a></li>
              <li>
                <a href="javascript:void(0);" class="navbar-link" data-target=".upcoming">Movies</a>
                <script>
                  document.querySelectorAll('.navbar-link').forEach(anchor => {
                      anchor.addEventListener('click', function (e) {
                          e.preventDefault();
                          const target = document.querySelector(this.getAttribute('data-target'));
                          if (target) {
                              target.scrollIntoView({ behavior: 'smooth' });
                          }
                      });
                  });
                </script>
              </li>
              <li>
                <a href="javascript:void(0);" class="navbar-link" data-target=".genres">Genres</a>
                <script>
                  document.querySelectorAll('.navbar-link').forEach(anchor => {
                      anchor.addEventListener('click', function (e) {
                          e.preventDefault();
                          const target = document.querySelector(this.getAttribute('data-target'));
                          if (target) {
                              target.scrollIntoView({ behavior: 'smooth' });
                          }
                      });
                  });
                </script>
              </li>
              <li>
                <?php if (isset($_SESSION['username'])): ?>
                  <a href="rentals.php?user_id=<?php echo $user_id; ?>" class="wishlist">Rentals</a>
                <?php endif; ?>
              </li>
              <li>
                <?php if (isset($_SESSION['username'])): ?>
                  <a href="wishlist.php?user_id=<?php echo $user_id; ?>" class="wishlist">Wishlist</a>
                <?php endif; ?>
              </li>
            </ul>
          </div>
        <div class="divider"></div>
          <div class="quicklink-wrapper">
            <ul class="quicklink-list">
              <li><a href="#" class="quicklink-link">Faq</a></li>
              <li><a href="#" class="quicklink-link">Help center</a></li>
              <li><a href="#" class="quicklink-link">Terms of use</a></li>
              <li><a href="#" class="quicklink-link">Privacy</a></li>
            </ul>
            <ul class="social-list">
              <li>
                <a href="#" class="social-link">
                  <ion-icon name="logo-facebook"></ion-icon>
                </a>
              </li>
              <li>
                <a href="#" class="social-link">
                  <ion-icon name="logo-twitter"></ion-icon>
                </a>
              </li>
              <li>
                <a href="#" class="social-link">
                  <ion-icon name="logo-pinterest"></ion-icon>
                </a>
              </li>
              <li>
                <a href="#" class="social-link">
                  <ion-icon name="logo-linkedin"></ion-icon>
                </a>
              </li>
            </ul>
          </div>
        </div>
      </div>
      <div class="footer-bottom">
        <div class="container">
          <p class="copyright">
            &copy; 2024 <a href="#">Forja.com</a>. All Rights Reserved
          </p>
        </div>
      </div>
    </footer>
    <!-- #GO TO TOP-->
    <a href="#top" class="go-top" data-go-top> <ion-icon name="chevron-up"></ion-icon></a>
    <!-- custom js link -->
    <script src="./assets/js/script.js"></script>
    <!-- ionicon link -->
    <script type="module" src="https://unpkg.com/ionicons@5.5.2/dist/ionicons/ionicons.esm.js"></script>
    <script nomodule src="https://unpkg.com/ionicons@5.5.2/dist/ionicons/ionicons.js"></script>
  </body>
</html>