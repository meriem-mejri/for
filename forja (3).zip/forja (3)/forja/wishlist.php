<?php
// Include the connection file
include 'connection/connect.php';
session_start();

// Check if the user is logged in
if (!isset($_SESSION['username'])) {
    echo "<script>alert('You must be logged in to view your wishlist.');</script>";
    exit;
}

// Get the user_id from the session
$username = $_SESSION['username'];

// Fetch the user_id from the database based on the username
$stmt = $conn->prepare('SELECT user_id FROM users WHERE username = ? LIMIT 1');
$stmt->bind_param('s', $username);  // 's' for string type
$stmt->execute();
$stmt->store_result();
if ($stmt->num_rows > 0) {
    $stmt->bind_result($user_id);
    $stmt->fetch();
} else {
    die('User not found.');
}
$stmt->close();

// Fetch the wishlist for the logged-in user
$stmt = $conn->prepare('
    SELECT w.wishlist_id, m.movie_id, m.title 
    FROM wishlist w 
    JOIN movies m ON w.movie_id = m.movie_id 
    WHERE w.user_id = ?');
$stmt->bind_param('i', $user_id);
$stmt->execute();
$result = $stmt->get_result();

// Handle movie removal
if (isset($_GET['delete'])) {
    $wishlist_id = intval($_GET['delete']);
    
    // Remove the movie from the wishlist
    $deleteStmt = $conn->prepare('DELETE FROM wishlist WHERE wishlist_id = ? AND user_id = ?');
    $deleteStmt->bind_param('ii', $wishlist_id, $user_id);
    if ($deleteStmt->execute()) {
        echo "<script>alert('Movie removed from wishlist.');</script>";
        header("Location: wishlist.php");  // Reload the page
    } else {
        echo "<script>alert('Failed to remove movie from wishlist.');</script>";
    }
}
?>

<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <link rel="shortcut icon" href="./assets/images/favicon.svg" type="image/svg+xml">
        <script src="https://kit.fontawesome.com/48967be5bb.js" crossorigin="anonymous"></script>
        <link href="https://cdn.jsdelivr.net/npm/remixicon@3.5.0/fonts/remixicon.css" rel="stylesheet"/>
        <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;500;600;700&display=swap" rel="stylesheet">
        <link rel="preconnect" href="https://fonts.googleapis.com">
        <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
        <link rel="stylesheet" href="./assets/css/style_rent.css">
        <title>Wishlist</title>
    </head>
    <body>
        <div class="wishlist_container">
            <h1>Wishlist</h1>
            <?php if ($result->num_rows > 0): ?>
            <?php while ($row = $result->fetch_assoc()): ?>
            <div class="wishlist-item">
                <span><?php echo htmlspecialchars($row['title']); ?></span>
                <!-- Add a trash icon with the confirmDelete function -->
                <button class="delete" onclick="confirmDelete(<?php echo $row['wishlist_id']; ?>)">
                    <i class="fa-solid fa-trash"></i>
                </button>
            </div>
            <?php endwhile; ?>
            <?php else: ?>
                <p>No movies in your wishlist.</p>
            <?php endif; ?>
            <script>
                // Function to confirm deletion before proceeding
                function confirmDelete(wishlistId) {
                    // Ask the user for confirmation
                    const confirmation = confirm("Are you sure you want to delete this movie from your wishlist?");
                    
                    if (confirmation) {
                    // If confirmed, redirect to the URL with the delete query
                    window.location.href = "wishlist.php?delete=" + wishlistId;
                    }
                }
            </script>
            <div style="text-align: center; margin-top: 20px;">
                <a href="index.php"class="yellow-rectangle"  >Back to Home</a>
            </div>  
        </div>
    </body>
</html>
<?php
    // Close the statement and connection
    $stmt->close();
    $conn->close();
?>