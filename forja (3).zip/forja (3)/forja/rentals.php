<?php
// Include the connection file
include 'connection/connect.php';
session_start();

// Check if the user is logged in
if (!isset($_SESSION['username'])) {
    echo "<script>alert('You must be logged in to view your rentals.');</script>";
    exit;
}

// Get the username from the session
$username = $_SESSION['username'];

// Fetch the user_id from the database based on the username
$stmt = $conn->prepare('SELECT user_id FROM users WHERE username = ? LIMIT 1');
$stmt->bind_param('s', $username);
$stmt->execute();
$stmt->store_result();
if ($stmt->num_rows > 0) {
    $stmt->bind_result($user_id);
    $stmt->fetch();
} else {
    die('User not found.');
}
$stmt->close();

// Fetch the rentals for the logged-in user
$stmt = $conn->prepare('
    SELECT r.rental_id, m.title, m.poster, r.rental_date, r.return_date, r.status
    FROM rentals r
    JOIN movies m ON r.movie_id = m.movie_id
    WHERE r.user_id = ?');
$stmt->bind_param('i', $user_id);
$stmt->execute();
$result = $stmt->get_result();
$hasRentals = $result->num_rows > 0;

// Handle movie removal
if (isset($_GET['delete'])) {
    $rental_id = intval($_GET['delete']);
    // Remove the movie from the rental list
    $deleteStmt = $conn->prepare('DELETE FROM rentals WHERE rental_id = ? AND user_id = ?');
    $deleteStmt->bind_param('ii', $rental_id, $user_id);
    if ($deleteStmt->execute()) {
        echo "<script>alert('Movie removed from rental list.');</script>";
        header("Location: rentals.php");  // Reload the page
    } else {
        echo "<script>alert('Failed to remove movie from rental list.');</script>";
    }
}
// Get today's date for rental date validation
$today = date('Y-m-d');
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="shortcut icon" href="./assets/images/favicon.svg" type="image/svg+xml">
    <script src="https://kit.fontawesome.com/48967be5bb.js" crossorigin="anonymous"></script>
    <link href="https://cdn.jsdelivr.net/npm/remixicon@3.5.0/fonts/remixicon.css" rel="stylesheet"/>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;500;600;700&display=swap" rel="stylesheet">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="./assets/css/style_rent.css" rel="stylesheet" >
    <title>Rentals</title>
</head>
<body>
    <div class="rentals_container">
        <h1>Rentals</h1>
        <?php if ($hasRentals): ?>
            <table class="table table-dark table-hover">
                <thead>
                    <tr>
                        <th scope="col">Movie</th>
                        <th scope="col">Rental Date</th>
                        <th scope="col">Return Date</th>
                        <th scope="col">Price (DT)</th>
                        <th scope="col">Status</th>
                        <th scope="col">Action</th>
                    </tr>
                </thead>
                <tbody>
                    <?php while ($row = $result->fetch_assoc()): ?>
                        <?php
                        // Format the rental date to YYYY-MM-DD
                        $rental_date_obj = new DateTime($row['rental_date']);
                        $formatted_rental_date = $rental_date_obj->format('Y-m-d');
                        
                        // Format the return date (if available) to YYYY-MM-DD
                        $formatted_return_date = $row['return_date'] ? (new DateTime($row['return_date']))->format('Y-m-d') : 'Not Returned';
                        
                        // Calculate the price based on rental duration
                        $return_date_obj = $row['return_date'] ? new DateTime($row['return_date']) : new DateTime();
                        $days_rented = $rental_date_obj->diff($return_date_obj)->days;
                        $price = $days_rented * 3; // 3 DT per day
                        ?>
                        <tr>
                            <td>
                                <div class="d-flex align-items-center">
                                    <!-- <img src="images/posters/<?= htmlspecialchars($row['poster']) ?>" alt="Poster" class="movie-poster me-3"> -->
                                    <span><?= htmlspecialchars($row['title']) ?></span>
                                </div>
                            </td>
                            <td><?= $formatted_rental_date ?></td>
                            <td>
                                <?php if ($row['return_date']): ?>
                                    <?= $formatted_return_date ?>
                                <?php else: ?>
                                    <span>Not Returned</span>
                                <?php endif; ?>
                            </td>
                            <td><?= $price ?> DT</td>
                            <td>
                                <?php
                                    if ($row['status'] === 'pending') {
                                        echo '<span class="badge badge-pending">Pending</span>';
                                    } elseif ($row['status'] === 'rented') {
                                        echo '<span class="badge badge-rented">Rented</span>';
                                    } elseif ($row['status'] === 'returned') {
                                        echo '<span class="badge badge-returned">Returned</span>';
                                    } elseif ($row['status'] === 'overdue') {
                                        echo '<span class="badge badge-overdue">Overdue</span>';
                                    }   
                                ?>
                            </td>

                            <td>
                                <?php if ($row['status'] === 'rented' or $row['status'] === 'pending' or $row['status'] === 'overdue'): ?>
                                    <a href="#" class="btn btn-outline-secondary btn-sm" data-bs-toggle="modal" data-bs-target="#editReturnDateModal<?= $row['rental_id'] ?>" title="Edit">✏️</a>

                                <?php else: ?>
                                    <a href="#" class="btn btn-outline-secondary btn-sm" onclick="return confirmDelete(<?php echo $row['rental_id']; ?>)" title="Delete">❌</a>
                                    <script>
                                        function confirmDelete(rentalId) {
                                            const confirmation = confirm("Are you sure you want to delete this movie from your rental list?");
                                            if (confirmation) {
                                                window.location.href = "rentals.php?delete=" + rentalId;
                                            }
                                            return false;
                                        }
                                    </script>
                                <?php endif; ?>
                            </td>
                        </tr>

                        <!-- Modal for Editing Return Date -->
                        <div class="modal fade" id="editReturnDateModal<?= $row['rental_id'] ?>" tabindex="-1" aria-labelledby="editReturnDateModalLabel<?= $row['rental_id'] ?>" aria-hidden="true">
                            <div class="modal-dialog">
                                <div class="modal-content">
                                    <div class="modal-header">
                                        <h5 class="modal-title" id="editReturnDateModalLabel<?= $row['rental_id'] ?>">Edit Return Date</h5>
                                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                                    </div>
                                    <div class="modal-body">
                                        <form method="POST" action="update_return_date.php">
                                            <input type="hidden" name="rental_id" value="<?= $row['rental_id'] ?>">
                                            <div class="mb-3">
                                                <label for="new_return_date" class="form-label">New Return Date</label>
                                                <input type="date" name="new_return_date" class="form-control" required min="<?= $today ?>">
                                            </div>
                                            <button type="submit" class="btn btn-primary">Update Return Date</button>
                                        </form>
                                    </div>
                                </div>
                            </div>
                        </div>
                    <?php endwhile; ?>
                </tbody>
            </table>
        <?php else: ?>
            <p class="text-center">You have no rentals yet.</p>
        <?php endif; ?>
        <div style="text-align: center; margin-top: 20px;">
            <a href="index.php" class="yellow-rectangle">Back to Home</a>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
<?php
    $stmt->close();
    $conn->close();
?>