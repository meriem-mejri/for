<?php
// Include the connection file
include 'connection/connect.php';
session_start();

// Check if the user is logged in
if (!isset($_SESSION['username'])) {
    echo "<script>alert('You must be logged in to update the return date.');</script>";
    exit;
}

// Get the username from the session
$username = $_SESSION['username'];

// Fetch the user_id from the database based on the username
$stmt = $conn->prepare('SELECT user_id FROM users WHERE username = ? LIMIT 1');
$stmt->bind_param('s', $username);
$stmt->execute();
$stmt->store_result();
if ($stmt->num_rows > 0) {
    $stmt->bind_result($user_id);
    $stmt->fetch();
} else {
    die('User not found.');
}
$stmt->close();

// Check if the necessary POST data is provided
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['rental_id']) && isset($_POST['new_return_date'])) {
    $rental_id = intval($_POST['rental_id']);
    $new_return_date = $_POST['new_return_date'];

    // Fetch the rental date to compare with the new return date
    $stmt = $conn->prepare('SELECT rental_date FROM rentals WHERE rental_id = ? AND user_id = ?');
    $stmt->bind_param('ii', $rental_id, $user_id);
    $stmt->execute();
    $stmt->store_result();

    if ($stmt->num_rows > 0) {
        $stmt->bind_result($rental_date);
        $stmt->fetch();

        // Convert rental date and new return date to DateTime objects and format them
        $rental_date_obj = new DateTime($rental_date);
        $new_return_date_obj = new DateTime($new_return_date);

        // Format the dates to YYYY-MM-DD (removes time)
        $formatted_rental_date = $rental_date_obj->format('Y-m-d');
        $formatted_new_return_date = $new_return_date_obj->format('Y-m-d');

        // Check if the new return date is after the rental date
        if ($formatted_new_return_date > $formatted_rental_date) {
            // Update the return date in the database
            $updateStmt = $conn->prepare('UPDATE rentals SET return_date = ? WHERE rental_id = ?');
            $updateStmt->bind_param('si', $formatted_new_return_date, $rental_id);
            
            if ($updateStmt->execute()) {
                echo "<script>alert('Return date updated successfully.'); window.location.href = 'rentals.php';</script>";
            } else {
                echo "<script>alert('Failed to update the return date.'); window.location.href = 'rentals.php';</script>";
            }

            $updateStmt->close();
        } else {
            echo "<script>alert('The new return date must be after the rental date.'); window.location.href = 'rentals.php';</script>";
        }
    } else {
        echo "<script>alert('Rental not found.'); window.location.href = 'rentals.php';</script>";
    }
    
    $stmt->close();
} else {
    echo "<script>alert('Invalid request.'); window.location.href = 'rentals.php';</script>";
}

$conn->close();
?>