<?php
    // Include database connection
    include 'connection/connect.php';
    session_start();

    // Check if the user is logged in
    if (!isset($_SESSION['username'])) {
        echo "<script>alert('You must be logged in to rent a movie.');</script>";
        header("Location: login.php");
        exit;
    }

    // Get movie_id from the URL
    if (!isset($_GET['movie_id'])) {
        echo "<script>alert('Movie ID is missing.');</script>";
        header("Location: index.php");
        exit;
    }

    $movie_id = $_GET['movie_id'];

    // Fetch movie details
    $stmt = $conn->prepare("SELECT title, poster FROM movies WHERE movie_id = ?");
    $stmt->bind_param('i', $movie_id);
    $stmt->execute();
    $result = $stmt->get_result();
    $movie = $result->fetch_assoc();
    $stmt->close();

    // Handle form submission
    if ($_SERVER['REQUEST_METHOD'] === 'POST') {
        $rental_date = $_POST['rental_date'];
        $return_date = $_POST['return_date'];

        // Validate dates
        if (new DateTime($return_date) <= new DateTime($rental_date)) {
            $error = "Return date must be after the rental date.";
        } else {
            // Calculate price
            $days = (new DateTime($rental_date))->diff(new DateTime($return_date))->days;
            $price = $days * 3; // 3 DT per day

            // Insert rental into database
            $username = $_SESSION['username'];
            $stmt = $conn->prepare("SELECT user_id FROM users WHERE username = ? LIMIT 1");
            $stmt->bind_param('s', $username);
            $stmt->execute();
            $stmt->bind_result($user_id);
            $stmt->fetch();
            $stmt->close();

            $stmt = $conn->prepare("INSERT INTO rentals (user_id, movie_id, rental_date, return_date) VALUES (?, ?, ?, ?)");
            $stmt->bind_param('iiss', $user_id, $movie_id, $rental_date, $return_date);
            $stmt->execute();
            $stmt->close();

            echo "<script>alert('Thank you for renting!');</script>";
            header("refresh:0.3;url=index.php");
        }
    }

    // Get today's date for rental date validation
    $today = date('Y-m-d');
?>

<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <link rel="shortcut icon" href="./assets/images/favicon.svg" type="image/svg+xml">
        <title>Rent Movie</title>
        <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
        <link rel="stylesheet" href="./assets/css/style_rent.css">
        <script>
            // Function to calculate the price
            function calculatePrice() {
                const rentalDate = document.getElementById('rental_date').value;
                const returnDate = document.getElementById('return_date').value;

                // Ensure both rental and return dates are selected
                if (!rentalDate || !returnDate) {
                    alert('Please select both rental and return dates.');
                    return;
                }

                // Convert the dates to Date objects for comparison
                const startDate = new Date(rentalDate);
                const endDate = new Date(returnDate);

                // Ensure the return date is after the rental date
                if (endDate <= startDate) {
                    alert('Return date must be after the rental date.');
                    return;
                }

                // Calculate the number of days between the dates
                const days = (endDate - startDate) / (1000 * 60 * 60 * 24);
                const price = days * 3; // 3 DT per day

                // Update the displayed price
                document.getElementById('price').innerText = `Total Price: ${price.toFixed(2)} DT`;

                // Enable the confirm rent button after calculating price
                document.getElementById('confirm_button').disabled = false;
                document.getElementById('price_display').style.display = 'block';  // Show price text
            }
        </script>
    </head>
    <body>
        <div class="rent_container">
            <h1 style="color:#e2d703">Rent :  <?= htmlspecialchars($movie['title']); ?></h1> <br><br>
            <div class="box">
                <div>
                    <img src="./assets/images/posters/<?= htmlspecialchars($movie['poster']); ?>" alt="Poster" class="img-thumbnail" style="max-width: 300px;">
                </div>
                <div >
                    <form method="POST" class="formbox">
                        <?php if (isset($error)): ?>
                            <div class="alert alert-danger"><?= $error; ?></div>
                        <?php endif; ?>

                        <!-- Rental Date -->
                        <div>
                            <label for="rental_date" class="form-label">Rental Date</label>
                            <input type="date" id="rental_date" name="rental_date" class="form-control" required min="<?= $today ?>">
                        </div>

                        <!-- Return Date -->
                        <div class="mb-3">
                            <label for="return_date" class="form-label">Return Date</label>
                            <input type="date" id="return_date" name="return_date" class="form-control" required min="<?= $today ?>">
                        </div> <br>

                        <!-- Button to Calculate Price -->
                        <button type="button" class="btn btn-outline-secondary mb-3" onclick="calculatePrice()">Calculate Price</button>
                        
                        <!-- Display Calculated Price -->
                        <p id="price_display" class="mb-3 text-danger" style="display:none;">
                            <span id="price"></span>
                        </p>
                        <!-- Confirm Rent Button -->
                        <button type="submit" id="confirm_button" class="btn btn-success" disabled>Confirm Rent</button>
                        <!-- Cancel Rent Button --> <br>
                        <button type="submit" class="btn btn-danger" onclick="location.href='movie-details.php?movie_id=<?php echo $movie_id; ?>'">Cancel</button> <br>
                    </form>
                </div>
            </div>
        </div>
        <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
    </body>
</html>